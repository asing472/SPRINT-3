﻿//Created by Akash Kumar Singh


using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Exceptions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using static System.Console;
using System.Text.RegularExpressions;
using Pecunia.Contracts.DALContracts;

namespace Pecunia.PresentationLayer
{
    class AccountsPresentation
    {
        /// <summary>
        /// Menu for Accounts Service
        /// </summary>
        /// <returns></returns>
        public static async Task<int> AccountsMenu()
        {
            int choice = -2;

            do
            {
                //Menu
                WriteLine("\n***********Accounts Menu***********");
                WriteLine("1. Create new account");
                WriteLine("2. Update/Modify account");
                WriteLine("3. Delete account");
                WriteLine("4. Search account");
                WriteLine("5. List all accounts");
                WriteLine("0. Logout");
                //WriteLine("-1. Exit");
                Write("Choice : ");
                //Accept and check choice
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1:
                            await CreateAccount();
                            break;
                        case 2:
                            await UpdateAccount();
                            break;
                        case 3:
                            await DeleteAccount();
                            break;
                        case 4:
                            await SearchAccount();
                            break;
                        case 5:
                            await ListAccount();
                            break;
                        case 0: break;

                    }
                }
                else
                {
                    choice = -2;
                }
            } while (choice != 0 && choice != -1);

            return choice;
        }


        /// <summary>
        /// Creating a new account
        /// </summary>
        /// <returns></returns>
        public static async Task CreateAccount()
        {
            CustomerBL cbl = new CustomerBL();
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {
                //Asking whether the customer already exists or not
                WriteLine("Enter 1 for existing customer\n");
                WriteLine("Enter 2 for new customer\n");
                int ch = Convert.ToInt32(ReadLine());

                //When the customer already exists
                if (ch == 1)
                {
                    WriteLine("Enter Customer No :");
                    string searchCustomerNo = ReadLine();
                    Customer customer = await cbl.GetCustomerByCustomerNumberBL(searchCustomerNo);


                    if (customer != null)
                    {
                        WriteLine("Select the type of account(Savings, Current or Fixed) :");
                        string accType = ReadLine();
                        if ((accType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
                        {
                            RegularAccount account = new RegularAccount();
                            WriteLine("Enter a Branch: ");
                            account.Branch = ReadLine();                           
                            account.CustomerID = customer.CustomerID;
                            if (accType.Equals("Savings", StringComparison.OrdinalIgnoreCase))
                                account.AccountType = "Savings";
                            if (accType.Equals("Current", StringComparison.OrdinalIgnoreCase))
                                account.AccountType = "Current";

                            bool isAdded = await abl.CreateAccountBL(account);
                            if (isAdded)
                            {
                                WriteLine(accType + " account created");
                                WriteLine("Account No.generated is: " + account.AccountNo);
                            }
                            else
                                WriteLine("Account not created");

                        }

                        else if (accType.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
                        {
                            FixedAccount fixedacc = new FixedAccount();
                            fixedacc.AccountType = "Fixed";
                            WriteLine("Enter a Branch: ");
                            fixedacc.Branch = ReadLine();
                            fixedacc.CustomerID = customer.CustomerID;
                            WriteLine("Enter Tenure");
                            fixedacc.Tenure = Double.Parse(ReadLine());
                            WriteLine("Enter FDDeposit Amount: ");
                            fixedacc.FDDeposit = Double.Parse(ReadLine());
                            bool fixaccountCreated = await fbl.CreateAccountBL(fixedacc);
                            if (fixaccountCreated)
                            {
                                WriteLine("Fixed account created");
                                WriteLine("Account No.generated is: " + fixedacc.AccountNo);
                            }
                            else
                                WriteLine("Account not created");
                        }

                    }

                    else
                    {
                       
                        WriteLine("No Customer details available");
                        
                    }

                }

                //When the customer is a new customer
                if (ch == 2)
                {
                    WriteLine("Enter Customer Details :");
                    string searchCustomerNo = await CustomerPresentation.AddCustomer();

                    Customer customer = await cbl.GetCustomerByCustomerNumberBL(searchCustomerNo);

                    if (customer != null)
                    {
                        WriteLine("Select the type of account(Savings, Current or Fixed) :");
                        string accType = ReadLine();

                        if ((accType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
                        {
                            RegularAccount account = new RegularAccount();
                            WriteLine("Enter a Branch: ");
                            account.Branch = ReadLine();
                            account.CustomerID = customer.CustomerID;
                            if (accType.Equals("Savings", StringComparison.OrdinalIgnoreCase))
                                account.AccountType = "Savings";
                            if (accType.Equals("Current", StringComparison.OrdinalIgnoreCase))
                                account.AccountType = "Current";

                            bool isAdded = await abl.CreateAccountBL(account);
                            if (isAdded)
                            {
                                WriteLine(accType + " account created");
                                WriteLine("Account No.generated is: " + account.AccountNo);
                            }
                            else
                                WriteLine("Account not created");

                        }

                        else if (accType.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
                        {
                            FixedAccount fixedacc = new FixedAccount();
                            fixedacc.AccountType = "Fixed";
                            fixedacc.CustomerID = customer.CustomerID;
                            WriteLine("Enter a Branch: ");
                            fixedacc.Branch = ReadLine();
                            WriteLine("Enter Tenure: ");
                            fixedacc.Tenure = Double.Parse(ReadLine());
                            WriteLine("Enter FDDeposit Amount: ");
                            fixedacc.FDDeposit = Double.Parse(ReadLine());

                            bool fixaccountCreated = await fbl.CreateAccountBL(fixedacc);
                            if (fixaccountCreated)
                            {
                                WriteLine("Fixed account created");
                                WriteLine("Account No.generated is: " + fixedacc.AccountNo);
                            }
                            else
                                WriteLine("Account not created");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }


        /// <summary>
        /// Updating the account branch or modifying the account branch
        /// </summary>
        /// <returns></returns>
        public static async Task UpdateAccount()
        {
            //CustomerBL cbl = new CustomerBL();
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {
                WriteLine("Enter 1 for updating branch \n");
                WriteLine("Enter 2 for modifying account type \n");
                int cha = Convert.ToInt32(ReadLine());
                switch (cha)
                {
                    case 1:

                        WriteLine("Enter the account number :\n");
                        string accno = ReadLine();
                        
                        RegularAccount account = await abl.GetAccountByAccountNoBL(accno);
                        FixedAccount fixacc = await fbl.GetAccountByAccountNoBL(accno);

                        //Invoke UpdateBranchBL to update the branch of Regular accounts
                        if (account != null)
                        {
                            using (IRegularAccountBL IregularAccountBL = new RegularAccountBL())
                            {
                                WriteLine("Enter the new account branch :\n");
                                account.Branch = ReadLine();
                                bool accountBranchUpdated = await IregularAccountBL.UpdateBranchBL(account);
                                if (accountBranchUpdated)
                                    WriteLine("Home branch updated");
                                else
                                    WriteLine("Home branch not Updated ");
                            }
                        }

                        //Invoke UpdateBranchBL to update the branch of Fixed accounts
                        else if (fixacc != null)
                        {
                            using (IFixedAccountBL IfixedAccountBL = new FixedAccountBL())
                            {
                                WriteLine("Enter the new account branch :\n");
                                fixacc.Branch = ReadLine();
                                bool accountBranchUpdated = await IfixedAccountBL.UpdateBranchBL(fixacc);
                                if (accountBranchUpdated)
                                    WriteLine("Home branch updated");
                                else
                                    WriteLine("Home branch not Updated ");
                            }
                        }

                       
                        else
                        {                           
                            WriteLine("No account details available");
                        }

                        break;

                    case 2:

                        WriteLine("Enter the account number :\n");
                        string accno2 = ReadLine();

                        RegularAccount account1 = await abl.GetAccountByAccountNoBL(accno2);
                        FixedAccount account2 = await fbl.GetAccountByAccountNoBL(accno2);

                        //Invoke UpdateAccountTypeBL to update the account type of Regular accounts
                        if (account1 != null)
                        {
                            using (IRegularAccountBL IregularAccountBL = new RegularAccountBL())
                            {
                                WriteLine("Enter the new account type(Savings or Current) :\n");
                                account1.AccountType = ReadLine();
                                bool accountTypeUpdated = await IregularAccountBL.UpdateAccountTypeBL(account1);
                                if (accountTypeUpdated)
                                    WriteLine("Account type updated");
                                else
                                    WriteLine("Account type not Updated ");
                            }
                        }
                        else if (account2 != null)
                        {
                            WriteLine("Fixed Accounts cannot be changed into other account type");
                        }

                        else
                        {
                           
                            WriteLine("No account details available");
                            
                        }

                        break;
                }
            }
            catch (Exception ex)
            {
                WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Deleting an existing account
        /// </summary>
        /// <returns></returns>
        public static async Task DeleteAccount()
        {
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {

                WriteLine("Enter the account number :\n");
                string accno = ReadLine();
                RegularAccount account1 = await abl.GetAccountByAccountNoBL(accno);
                FixedAccount account2 = await fbl.GetAccountByAccountNoBL(accno);
                if (account1 != null)
                {

                    bool accountDeleted = await abl.DeleteAccountBL(accno);
                    if (accountDeleted)
                        WriteLine("Account deleted");
                    else
                        WriteLine("Account not deleted");
                }

                else if (account2 != null)
                {

                    bool accountDeleted = await fbl.DeleteAccountBL(accno);
                    if (accountDeleted)
                        WriteLine("Account deleted");
                    else
                        WriteLine("Account not deleted");
                }

                else
                {
                    WriteLine("No account details available");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }


        /// <summary>
        /// Searching the accounts based on various criteria
        /// </summary>
        /// <returns>Returns RegularAccount or FixedAccount object</returns>
        public static async Task SearchAccount()
        {
            //CustomerBL cbl = new CustomerBL();
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {
                WriteLine("1.Search account by account number:");
                WriteLine("2.Search accounts by CustomerNo:");
                WriteLine("3.Search accounts by account type:");
                WriteLine("4.Search account by home branch:");
                WriteLine("5.Search account by date:");

                int option = Convert.ToInt32(ReadLine());
                switch (option)
                {
                    case 1:

                        string accno;
                        WriteLine("Enter account number to search:");
                        accno = ReadLine();
                        RegularAccount account1 = await abl.GetAccountByAccountNoBL(accno);
                        FixedAccount account2 = await fbl.GetAccountByAccountNoBL(accno);
                        if (account1 != null)
                        {
                            
                            WriteLine("************************************************************************************************************");
                            WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                            WriteLine("************************************************************************************************************");
                            WriteLine($" {account1.AccountNo}\t {account1.AccountType}\t { account1.CurrentBalance}\t{ account1.Branch}\t {account1.Status}\t {account1.CreationDateTime}\t{account1.LastModifiedDateTime}");
                            WriteLine("************************************************************************************************************");
                        }

                        else if (account2 != null)
                        {
                            WriteLine("*************************************************************************************************************************************");
                            WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            WriteLine("*************************************************************************************************************************************");
                            WriteLine($" {account2.AccountNo}\t {account2.AccountType}\t { account2.CurrentBalance}\t{ account2.Branch}\t {account2.Status}\t{account2.Tenure}\t{account2.FDDeposit}\t{account2.CreationDateTime}\t{account2.LastModifiedDateTime}");
                            WriteLine("*************************************************************************************************************************************");
                        }

                        else
                        {
                            WriteLine("No account details available");
                        }

                        break;

                    case 2:

                        string custNo;
                        WriteLine("Enter customer No to search:");
                        custNo = ReadLine();
                        Customer customer = new Customer();
                        CustomerBL custBL = new CustomerBL();
                        customer = await custBL.GetCustomerByCustomerNumberBL(custNo);
                        List<RegularAccount> regaccountsbycustNo = await abl.GetAccountsByCustomerNoBL(customer.CustomerID);
                        List<FixedAccount> fixaccountsbycustNo = await fbl.GetAccountsByCustomerNoBL(customer.CustomerID);
                        if (regaccountsbycustNo.Count != 0)
                        {
                            WriteLine("************************************************************************************************************");
                            WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                            WriteLine("************************************************************************************************************");
                            foreach (RegularAccount regacc1 in regaccountsbycustNo)
                            {
                                WriteLine($"{custNo}\t{regacc1.AccountNo}\t {regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                            }
                            WriteLine("************************************************************************************************************");
                        }

                        if (fixaccountsbycustNo.Count != 0)
                        {
                            WriteLine("*************************************************************************************************************************************");
                            WriteLine("Customer No\tAccount No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            WriteLine("*************************************************************************************************************************************");
                            foreach (FixedAccount acc in fixaccountsbycustNo)
                            {
                                WriteLine($"{custNo}\t {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            WriteLine("*************************************************************************************************************************************");

                        }

                        else
                        {
                            WriteLine("No Customer Details available");
                        }

                        break;


                    case 3:

                        string accType;
                        WriteLine("Enter account type to search:");
                        accType = ReadLine();

                        if ((accType.Equals("Savings", StringComparison.OrdinalIgnoreCase)) || (accType.Equals("Current", StringComparison.OrdinalIgnoreCase)))
                        {
                            List<RegularAccount> accountsbytype = await abl.GetAccountsByTypeBL(accType);
                            if (accountsbytype.Count != 0)
                            {
                                WriteLine("************************************************************************************************************");
                                WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                                WriteLine("************************************************************************************************************");
                                foreach (RegularAccount regacc1 in accountsbytype)
                                {
                                    WriteLine($"{regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                                }
                                WriteLine("************************************************************************************************************");
                            }
                            else
                            {
                                WriteLine("No Regular Accounts Details Available");
                            }
                        }
                        else if (accType.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
                        {
                            List<FixedAccount> fixaccounts = await fbl.GetAllAccountsBL();
                            if (fixaccounts.Count != 0)
                            {
                                WriteLine("*************************************************************************************************************************************");
                                WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                                WriteLine("*************************************************************************************************************************************");
                                foreach (FixedAccount acc in fixaccounts)
                                {
                                    WriteLine($"{acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                                }
                                WriteLine("*************************************************************************************************************************************");

                            }

                            else
                            {
                                WriteLine("No Fixed Account Details Available");
                            }
                        }

                        break;

                    case 4:

                        string branch;
                        WriteLine("Enter home branch to search:");
                        branch = ReadLine();
                        List<RegularAccount> regaccountsbybranch = await abl.GetAccountsByBranchBL(branch);
                        List<FixedAccount> fixaccountsbybranch = await fbl.GetAccountsByBranchBL(branch);

                        if (regaccountsbybranch.Count != 0)
                        {
                            WriteLine("************************************************************************************************************");
                            WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                            WriteLine("************************************************************************************************************");
                            foreach (RegularAccount regacc1 in regaccountsbybranch)
                            {
                                WriteLine($"{regacc1.AccountNo}\t {regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                            }
                            WriteLine("************************************************************************************************************");
                        }

                        if (fixaccountsbybranch.Count != 0)
                        {
                            WriteLine("*************************************************************************************************************************************");
                            WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            WriteLine("*************************************************************************************************************************************");
                            foreach (FixedAccount acc in fixaccountsbybranch)
                            {
                                WriteLine($"{acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            WriteLine("*************************************************************************************************************************************");
                        }

                        else
                        { 
                            WriteLine("No Accounts Details Available");
                        }

                        break;


                    case 5:

                        DateTime date1;
                        DateTime date2;
                        WriteLine("Enter the range of dates to search (in yyyy/MM/dd format):");
                        WriteLine("Start Date : ");
                        date1 = Convert.ToDateTime(ReadLine());
                        WriteLine("End Date : ");
                        date2 = Convert.ToDateTime(ReadLine());

                        if (date2.Ticks > (DateTime.Now).Ticks)
                        {
                            WriteLine("End Date can't be later than today");
                            break;

                        }

                        List<RegularAccount> regaccountsbydate = await abl.GetAccountsByAccountOpeningDateBL(date1, date2);
                        List<FixedAccount> fixaccountsbydate = await fbl.GetAccountsByAccountOpeningDateBL(date1, date2);

                        if (regaccountsbydate.Count != 0)
                        {
                            WriteLine("************************************************************************************************************");
                            WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                            WriteLine("************************************************************************************************************");
                            foreach (RegularAccount regacc1 in regaccountsbydate)
                            {
                                WriteLine($" {regacc1.AccountNo}\t {regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                            }
                            WriteLine("************************************************************************************************************");
                        }

                        if (fixaccountsbydate.Count != 0)
                        {
                            WriteLine("*************************************************************************************************************************************");
                            WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                            WriteLine("*************************************************************************************************************************************");
                            foreach (FixedAccount acc in fixaccountsbydate)
                            {
                                WriteLine($"{acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                            }
                            WriteLine("*************************************************************************************************************************************");
                        }

                        else
                        {

                            string pattern = @"\d{4}/\d{2}/\d{2}";
                            Regex rg = new Regex(pattern);
                            bool match1 = rg.IsMatch(date1.ToString());
                            bool match2 = rg.IsMatch(date2.ToString());
                           
                            if ((match1 == true) && (match2 == true))
                            {
                                if ((regaccountsbydate.Count == 0) && (fixaccountsbydate.Count == 0))
                                {
                                    WriteLine("No Account Details Available for these dates");
                                }

                            }

                            else
                            {
                                WriteLine("Entered dates not in valid format");
                            }

                        }

                        break;
                }

            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// Listing all accounts
        /// </summary>
        /// <returns>Returns RegularAccount or FixedAccount object</returns>
        public static async Task ListAccount()
        {
            RegularAccountBL abl = new RegularAccountBL();
            FixedAccountBL fbl = new FixedAccountBL();
            try
            {
                List<RegularAccount> regaccounts = await abl.GetAllAccountsBL();
                if (regaccounts.Count != 0)
                {
                    WriteLine("Available Regular Accounts are:");
                    WriteLine("************************************************************************************************************");
                    WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tCreation Date\tLast Modified");
                    WriteLine("************************************************************************************************************");
                    foreach (RegularAccount regacc1 in RegularAccountDALBase.regularAccountList)
                    {
                        WriteLine($"{regacc1.AccountNo}\t {regacc1.AccountType}\t { regacc1.CurrentBalance}\t{ regacc1.Branch}\t {regacc1.Status}\t {regacc1.CreationDateTime}\t{regacc1.LastModifiedDateTime}");
                    }
                    WriteLine("************************************************************************************************************");
                }

                List<FixedAccount> fixaccounts = await fbl.GetAllAccountsBL();
                if (fixaccounts.Count != 0)
                {
                    WriteLine("Available Fixed Accounts are:");
                    WriteLine("*************************************************************************************************************************************");
                    WriteLine("Account No\tAccount Type\tBalance\tBranch\tStatus\tTenure\tFDDeposit\tCreation Date\tLast Modified");
                    WriteLine("*************************************************************************************************************************************");
                    foreach (FixedAccount acc in fixaccounts)
                    {
                        WriteLine($" {acc.AccountNo}\t {acc.AccountType}\t { acc.CurrentBalance}\t{ acc.Branch}\t {acc.Status}\t{acc.Tenure}\t{acc.FDDeposit}\t{acc.CreationDateTime}\t{ acc.LastModifiedDateTime}");
                    }
                    WriteLine("*************************************************************************************************************************************");
                }
            }
            catch (Exception ex)
            {
                ExceptionLogger.LogException(ex);
                WriteLine(ex.Message);
            }
        }
    }

}