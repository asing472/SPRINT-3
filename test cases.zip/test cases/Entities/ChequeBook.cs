﻿using Pecunia.Helpers.ValidationAttribute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{/// <summary>
 /// Interface for ChequeBook Entity
 /// </summary>
    public interface IChequeBook
    {
        Guid ChequeBookID { get; set; }
        Guid AccountID { get; set; }
        string AccountNo { get; set; }
        double SeriesStart { get; set; }
        DateTime ChequeBookRequestDate { get; set; }
        DateTime LastModifiedDate { get; set; }
        int NumberOfLeaves { get; set; }
        string ChequeBookStatus { get; set; }

    }

    /// <summary>
    /// Represents DebitCard
    /// </summary>
    public class ChequeBook : IChequeBook
    {/* Auto-Implemented Properties */

        [Required("ChequeBook ID can't be blank.")]
        public Guid ChequeBookID { get; set; }
        [Required("Account ID can't be blank.")]
        public Guid AccountID { get; set; }
        [Required("AccountNo can't be null")]
        [RegExp(@"^[1]\d{9}$", "Account number should start with 1 and should have 10 digits")]
        public string AccountNo { get; set; }
        [RegExp(@"^([0-9]{6})$", "Length of the series should be 6")]
        public double SeriesStart { get; set; }
        public DateTime ChequeBookRequestDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
        [Required("Number of leaves can't be blank.")]
        public int NumberOfLeaves { get; set; }
        public string ChequeBookStatus { get; set; }
        public ChequeBook()
        {
            ChequeBookID = default(Guid);
            AccountID = default(Guid);
            AccountNo = null;
            SeriesStart = default(long);
            NumberOfLeaves = default(int);
            ChequeBookStatus = null;

        }

    }
}
