﻿using Pecunia.Helpers.ValidationAttribute;
using System;

namespace Pecunia.Entities
{/// <summary>
 /// Interface for CreditCard Entity
 /// </summary>
    public interface ICreditCard
    {
        Guid CreditCardID { get; set; }
        Guid CustomerID { get; set; }

        double CreditLimit { get; set; }
        string CustomerNameAsPerCard { get; set; }
        string CardNumber { get; set; }
        DateTime CardIssueDate { get; set; }
        DateTime LastModifiedDate { get; set; }
        string ExpiryMMYYYY { get; set; }
        string CardType { get; set; }
        string CardStatus { get; set; }

    }
    /// <summary>
    /// Represents CreditCard
    /// </summary>
    public class CreditCard : ICreditCard
    {/* Auto-Implemented Properties */


        public Guid CreditCardID { get; set; }
        public Guid CustomerID { get; set; }
        [Required("Customer Name can't be blank.")]
        [RegExp(@"^(\w{2,40})$", "Customer Name should contain only 2 to 40 characters.")]
        public string CustomerNameAsPerCard { get; set; }
        public string CardNumber { get; set; }
        //[Required("Credit Limit can't be blank.")]
        public double CreditLimit { get; set; }
        public DateTime CardIssueDate { get; set; }
        public DateTime LastModifiedDate { get; set; }
        public string ExpiryMMYYYY { get; set; }
        [Required("Card type can't be blank.")]
        public string CardType { get; set; }
        [Required("Card status cannot be blank.")]
        public string CardStatus { get; set; }

        public CreditCard()
        {
            CreditCardID = default(Guid);
            CustomerID = default(Guid);
            CustomerNameAsPerCard = null;
            CardNumber = null;
            CreditLimit = default(double);
            CardType = null;
            CardStatus = null;
        }


    }

}
