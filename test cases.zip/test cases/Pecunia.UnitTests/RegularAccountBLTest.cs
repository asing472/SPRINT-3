﻿//Created by Akash Kumar Singh

using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pecunia.Entities;
using Pecunia.BusinessLayer;
using System.Collections.Generic;



namespace Pecunia.UnitTest
{
    [TestClass]
    public class RegularAccountBLTest
    {

        /// <summary>
        /// Creating valid regular account
        /// </summary>
        [TestMethod]
        public async Task CreateValidRegularAccount()
        {
            //Arrange
            
            //Adding a customer
            Customer customer = new Customer
            {
                CustomerName = "Saanu",
                CustomerMobile = "9876048857",
                CustomerAddress = "ScZXCV254GV",
                Email = "saanu@gmail.com",
                CustomerAadharNumber = "758230998651",
                CustomerPANNumber = "BLKPC1922K",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1997-02-22"),
                WorkExperience = 3.5,
                AnnualIncome = 234567
            };

            bool isAdded1 = false; 
            CustomerBL customerBL = new CustomerBL();
            isAdded1 =  await customerBL.AddCustomerBL(customer);

            //Creating a new account
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Savings", Branch = "Delhi" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Customer ID should be valid
        /// </summary>
        [TestMethod]
        public async Task CustomerIDshouldBeValid()
        {
            //Arrange
    
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerID = default(Guid), AccountType = "Savings", Branch = "Mumbai" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Type can't be null
        /// </summary>
        [TestMethod]
        public async Task AccountTypeCanNotBeNull()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Kavyanjali",
                CustomerMobile = "8104000000",
                CustomerAddress = "Ambikapur",
                Email = "kavyanjali@outlook.com",
                CustomerAadharNumber = "111260009651",
                CustomerPANNumber = "MMAAW4980B",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = null, Branch = "mumbai" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch can't be null
        /// </summary>
        [TestMethod]
        public async Task BranchCanNotBeNull()
        {


            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Deepa",
                CustomerMobile = "9828225555",
                CustomerAddress = "Bilaspur",
                Email = "deepakumari@gmail.com",
                CustomerAadharNumber = "112311589651",
                CustomerPANNumber = "BOQOP1911Z",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1989-03-07"),
                WorkExperience = 1,
                AnnualIncome = 8000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Current", Branch = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        
        /// <summary>
        /// Customer No should not be new
        /// </summary>
        [TestMethod]
        public async Task CustomerIDShouldNotBeNew()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerID = Guid.NewGuid(), AccountType = "Savings", Branch = "Bengaluru" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

    
        /// <summary>
        /// Account Type should be valid
        /// </summary>
        [TestMethod]
        public async Task AccountTypeShouldBeValid()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Deepak",
                CustomerMobile = "9828005555",
                CustomerAddress = "Bilaspur",
                Email = "deepak@gmail.com",
                CustomerAadharNumber = "111111589651",
                CustomerPANNumber = "BBQOP1911Z",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1989-03-07"),
                WorkExperience = 1,
                AnnualIncome = 8000000
            };
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Salary", Branch = "Bengaluru" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch should be in ("Mumbai","Delhi","Chennai","Bengaluru")
        /// </summary>
        [TestMethod]
        public async Task BranchShouldBeValid()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer
            {
                CustomerName = "Ajaya",
                CustomerMobile = "9824497234",
                CustomerAddress = "Raigarh",
                Email = "ajaya@outlook.com",
                CustomerAadharNumber = "485632785888",
                CustomerPANNumber = "ADKPC1988M",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("199-02-12"),
                WorkExperience = 3.5,
                AnnualIncome = 2347
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Current", Branch = "Kolkata" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// branch should be valid
        /// </summary>
        [TestMethod]
        public async Task UpdateValidBranch()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer
            {
                CustomerName = "Kavya",
                CustomerMobile = "8104000111",
                CustomerAddress = "Ambikapur",
                Email = "kavya@outlook.com",
                CustomerAadharNumber = "111268589651",
                CustomerPANNumber = "MMAAW4986R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount()
            {
                CustomerID = customer.CustomerID,
                AccountType = "Savings",
                Branch = "Mumbai"
            };

            bool isAdded = false;
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount1);
                RegularAccount regularAccount = new RegularAccount() { AccountID = regularAccount1.AccountID, AccountNo = regularAccount1.AccountNo,CustomerID = regularAccount1.CustomerID,AccountType="Savings",Branch="Chennai"};
                isUpdated = await regularBL.UpdateBranchBL(regularAccount);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch should be in ("Mumbai","Delhi","Chennai","Bengaluru") while updating the record
        /// </summary>
        [TestMethod]
        public async Task UpdateValidBranchError()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer
            {
                CustomerName = "Aishwarya",
                CustomerMobile = "8227997680",
                CustomerAddress = "Raigarh",
                Email = "aish@gmail.com",
                CustomerAadharNumber = "825738288881",
                CustomerPANNumber = "ADEWC1981Q",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1992-02-12"),
                WorkExperience = 3.5,
                AnnualIncome = 2347
            };
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Current", Branch = "Bengaluru" };
            bool isAdded = false;
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount);
                RegularAccount regularAccount1 = new RegularAccount() { AccountID = regularAccount.AccountID, CustomerID = regularAccount.CustomerID, AccountType = "Current", Branch = "Shimla" };
                isUpdated = await regularBL.UpdateBranchBL(regularAccount1);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Account no should be valid
        /// </summary>
       [TestMethod]
        public async Task UpdateAccountnoShouldBeValid()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer
            {
                CustomerName = "Manoj",
                CustomerMobile = "8727584444",
                CustomerAddress = "Ambikapur",
                Email = "manu@outlook.com",
                CustomerAadharNumber = "555568589651",
                CustomerPANNumber = "MMQQM1186R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount()
            {
                CustomerID = customer.CustomerID,
                AccountType = "Savings",
                Branch = "Mumbai"
            };

            bool isAdded = false;
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount1);
                RegularAccount regularAccount = new RegularAccount() {AccountNo = "5687", CustomerID = regularAccount1.CustomerID, AccountType = "Savings", Branch = "Chennai" };
                isUpdated = await regularBL.UpdateBranchBL(regularAccount);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Account type should be valid 
        /// </summary>
        [TestMethod]
        public async Task UpdateValidAccountType()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Monika",
                CustomerMobile = "9828965111",
                CustomerAddress = "Bilaspur",
                Email = "midia@gmail.com",
                CustomerAadharNumber = "825738589651",
                CustomerPANNumber = "MMQOP1985R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1959-03-07"),
                WorkExperience = 1,
                AnnualIncome = 8000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount()
            {
                
                CustomerID = customer.CustomerID,
                AccountType = "Current",
                Branch = "Bengaluru"
            };

            bool isAdded = false;
            bool isUpdated = true;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount1);
                RegularAccount regularAccount = new RegularAccount() { AccountNo = regularAccount1.AccountNo, CustomerID = regularAccount1.CustomerID, AccountType = "Savings",Branch=regularAccount1.Branch};
                isUpdated = await regularBL.UpdateAccountTypeBL(regularAccount);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// When Account type is invalid 
        /// </summary>
        [TestMethod]
        public async Task UpdateValidAccountTypeError()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Ambresh",
                CustomerMobile = "9884565111",
                CustomerAddress = "Badlapur",
                Email = "ambar@gmail.com",
                CustomerAadharNumber = "796538589651",
                CustomerPANNumber = "MMQQW7896R",
                CustomerGender = PecuniaHelpers.Gender.Transgender,
                CustomerDOB = Convert.ToDateTime("1995-12-05"),
                WorkExperience = 3,
                AnnualIncome = 7000000
            };
            bool isAdded1 = false;
            CustomerBL customerBL = new CustomerBL();
            isAdded1 = await customerBL.AddCustomerBL(customer);

            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Recurring Deposit",
                Branch = "Chennai"
            };

            bool isAdded = false;
            bool isUpdated = true;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount1);
                RegularAccount regularAccount = new RegularAccount() { AccountNo = regularAccount1.AccountNo, CustomerID = regularAccount1.CustomerID, AccountType = "Savings", Branch = regularAccount1.Branch };
                isUpdated = await regularBL.UpdateAccountTypeBL(regularAccount);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Delete Valid Account
        /// </summary>
        [TestMethod]
        public async Task DeleteValidAccount()
        {
            //Arrange
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Sita",
                CustomerMobile = "9884565321",
                CustomerAddress = "Nagpur",
                Email = "sita@gmail.com",
                CustomerAadharNumber = "716538512451",
                CustomerPANNumber = "GGIKW7896R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1990-12-05"),
                WorkExperience = 3,
                AnnualIncome = 7000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();
            isAddedcust = await customerBL.AddCustomerBL(customer);

            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Current", Branch = "Delhi" };
            bool isAdded = false;
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount);
                isDeleted = await regularBL.DeleteAccountBL(regularAccount.AccountNo);

            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isDeleted, errorMessage);
            }
        }


        /// <summary>
        /// Deleting account when Account no is not valid
        /// </summary>
        [TestMethod]
        public async Task DeleteAccountNoShouldBeValid()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            //RegularAccount regularAccount = new RegularAccount() { CustomerNo = "100001", AccountType = "Current", Branch = "Delhi" };
            //bool isAdded = false;
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                //isAdded = await regularBL.CreateAccountBL(regularAccount);
                isDeleted = await regularBL.DeleteAccountBL("10006523");

            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isDeleted, errorMessage);
            }
        }

        /// <summary>
        /// Search Account by Valid Account No
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByValidAccountNo()
        {
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Aisha",
                CustomerMobile = "9824565771",
                CustomerAddress = "Ambikapur",
                Email = "aiishu@outlook.com",
                CustomerAadharNumber = "696968589651",
                CustomerPANNumber = "SIITW4986R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();
            isAddedcust = await customerBL.AddCustomerBL(customer);

            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Savings", Branch = "Mumbai" };
            bool isAdded = false;
            bool isSearched = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount);
                if (regularAccount.Equals(await regularBL.GetAccountByAccountNoBL(regularAccount.AccountNo)))
                {
                    isSearched = true;
                }


            }
            catch (Exception ex)
            {
                isSearched = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isSearched, errorMessage);
            }
        }


        /// <summary>
        /// Account number should be a valid account number
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByAccountNoError()
        {
            //Arrange //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Vimal",
                CustomerMobile = "8108888111",
                CustomerAddress = "Rampur",
                Email = "viji@outlook.com",
                CustomerAadharNumber = "111168589651",
                CustomerPANNumber = "MNBVW4986R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1985-10-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount RegularAccount = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Current", Branch = "Bengaluru"};
            bool isAdded = false;
            bool isSearched = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(RegularAccount);
                if (RegularAccount.Equals(await regularBL.GetAccountByAccountNoBL("2014785")))
                {
                    isSearched = true;
                }


            }
            catch (Exception ex)
            {
                isSearched = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isSearched, errorMessage);
            }
        }


        /// <summary>
        /// Search Account by Customer 
        /// </summary>

        [TestMethod]
        public async Task SearchAccountByValidCustomer()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Avinay",
                CustomerMobile = "8104522211",
                CustomerAddress = "Ambikapur",
                Email = "avin@outlook.com",
                CustomerAadharNumber = "845268580987",
                CustomerPANNumber = "TTYYW4986R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;

            CustomerBL customerBL = new CustomerBL();
            isAddedcust = await customerBL.AddCustomerBL(customer);
            
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Savings",
                Branch = "Chennai"
            };
            RegularAccount regularAccount2 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Current",
                Branch = "Mumbai"
            };

            bool isAdded1 = false;
            bool isAdded2 = false;

            List<RegularAccount> result = new List<RegularAccount>();
            
            result.Add(regularAccount1);
            result.Add(regularAccount2);
            
            List<RegularAccount> isSearched = new List<RegularAccount>();
            //bool isSearched = true;
            string errorMessage = null;

            //Act
            try
            {
                isAdded1 = await regularBL.CreateAccountBL(regularAccount1);
                isAdded2 = await regularBL.CreateAccountBL(regularAccount2);
                
                isSearched = await regularBL.GetAccountsByCustomerNoBL(customer.CustomerID);
            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(result, isSearched);
                //Assert.IsTrue(isSearched, errorMessage);
            }
        }


        /// <summary>
        /// Search Account by Valid Account Type
        /// </summary>

        [TestMethod]
        public async Task SearchAccountByValidAccountType()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Kavita",
                CustomerMobile = "8104444111",
                CustomerAddress = "Shibpur",
                Email = "kavita@outlook.com",
                CustomerAadharNumber = "254168589651",
                CustomerPANNumber = "OOKKW4986R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;

            CustomerBL customerBL = new CustomerBL();

            //Adding a new customer
            Customer customer2 = new Customer()
            {
                CustomerName = "Kavyanjali",
                CustomerMobile = "8104000000",
                CustomerAddress = "Ambikapur",
                Email = "kavyanjali@outlook.com",
                CustomerAadharNumber = "111260009651",
                CustomerPANNumber = "MMAAW4980B",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust2 = false;

            isAddedcust = await customerBL.AddCustomerBL(customer);

            RegularAccountBL regularBL = new RegularAccountBL();

            RegularAccount regularAccount1 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Savings",
                Branch = "Chennai"
            };
            RegularAccount regularAccount2 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Current",
                Branch = "Mumbai"
            };
            RegularAccount regularAccount3 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Savings",
                Branch = "Chennai"
            };
            RegularAccount regularAccount4 = new RegularAccount()
            {

                CustomerID = customer2.CustomerID,
                AccountType = "Savings",
                Branch = "Delhi"
            };

            bool isAdded1 = false;
            bool isAdded2 = false;
            bool isAdded3 = false;
            bool isAdded4 = false;

            List<RegularAccount> result = new List<RegularAccount>();

            result.Add(regularAccount1);
            result.Add(regularAccount3);

            List<RegularAccount> isSearched = new List<RegularAccount>();
            //bool isSearched = true;
            string errorMessage = null;

            //Act
            try
            {
                isAddedcust = await customerBL.AddCustomerBL(customer);
                isAddedcust2 = await customerBL.AddCustomerBL(customer);
                isAdded1 = await regularBL.CreateAccountBL(regularAccount1);
                isAdded2 = await regularBL.CreateAccountBL(regularAccount2);
                isAdded3 = await regularBL.CreateAccountBL(regularAccount3);
                isAdded4 = await regularBL.CreateAccountBL(regularAccount4);

                isSearched = await regularBL.GetAccountsByTypeBL("Savings");
            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(result, isSearched);
                //Assert.IsTrue(isSearched, errorMessage);
            }
        }



        /// <summary>
        /// Search Account by Invalid Customer No
        /// </summary>

        [TestMethod]
        public async Task SearchAccountByCustomerError()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Avishi",
                CustomerMobile = "8193105111",
                CustomerAddress = "Ambikapur",
                Email = "avishirocks@outlook.com",
                CustomerAadharNumber = "226968580909",
                CustomerPANNumber = "MLOPW4986R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;

            CustomerBL customerBL = new CustomerBL();
            isAddedcust = await customerBL.AddCustomerBL(customer);

            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Savings",
                Branch = "Mumbai"
            };

            bool isAdded1 = false;

            List<RegularAccount> result = new List<RegularAccount>();

            result.Add(regularAccount1);

            List<RegularAccount> isSearched = new List<RegularAccount>();
            //bool isSearched = true;
            string errorMessage = null;

            //Act
            try
            {
                isAdded1 = await regularBL.CreateAccountBL(regularAccount1);
                isSearched = await regularBL.GetAccountsByCustomerNoBL(new Guid());
            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.AreNotEqual(result, isSearched);
                //Assert.IsTrue(isSearched, errorMessage);

            }
        }

        /// <summary>
        /// Account Type should be Valid
        /// </summary>

        [TestMethod]
        public async Task SearchAccountByAccountType()
        {
            //Arrange

            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Manoj",
                CustomerMobile = "8727584444",
                CustomerAddress = "Ambikapur",
                Email = "manu@outlook.com",
                CustomerAadharNumber = "555568589651",
                CustomerPANNumber = "MMQQM1186R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;

            CustomerBL customerBL = new CustomerBL();
            

            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Savings",
                Branch = "Chennai"
            };
            RegularAccount regularAccount2 = new RegularAccount()
            {

                CustomerID = customer.CustomerID,
                AccountType = "Current",
                Branch = "Mumbai"
            };

            bool isAdded1 = false;
            bool isAdded2 = false;

            List<RegularAccount> result = new List<RegularAccount>();

            List<RegularAccount> isSearched = new List<RegularAccount>();
            //bool isSearched = true;
            string errorMessage = null;

            //Act
            try
            {
                isAddedcust = await customerBL.AddCustomerBL(customer);
                isAdded1 = await regularBL.CreateAccountBL(regularAccount1);
                isAdded2 = await regularBL.CreateAccountBL(regularAccount2);

                isSearched = await regularBL.GetAccountsByTypeBL("Salary");
            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(result, isSearched);
                //Assert.IsTrue(isSearched, errorMessage);
            }
        }

        /// <summary>
        /// Search Account by Valid home branch
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByValidBranch()
        {
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Savita",
                CustomerMobile = "9824565444",
                CustomerAddress = "Ambikapur",
                Email = "nishusav@outlook.com",
                CustomerAadharNumber = "222268589561",
                CustomerPANNumber = "SSIIW4986R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();
            

            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Savings", Branch = "Mumbai" };
            bool isAdded1 = false;
            
            RegularAccount regularAccount2 = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Savings", Branch = "Bengaluru" };
            bool isAdded2 = false;
            
            RegularAccount regularAccount3 = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Current", Branch = "Mumbai" };
            bool isAdded3 = false;
            
            string errorMessage = null;

            List <RegularAccount> result = new List<RegularAccount>();
            result.Add(regularAccount1);
            result.Add(regularAccount3);

            List<RegularAccount> isSearched = new List<RegularAccount>();
            //Act
            try
            {
                isAddedcust = await customerBL.AddCustomerBL(customer);
                isAdded1 = await regularBL.CreateAccountBL(regularAccount1);
                isAdded2 = await regularBL.CreateAccountBL(regularAccount2);
                isAdded3 = await regularBL.CreateAccountBL(regularAccount3);
                isSearched = await regularBL.GetAccountsByBranchBL("Mumbai");

            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(isSearched, result);
            }
        }

        /// <summary>
        /// Home branch should be valid
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByBranchError()
        {
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Savitri",
                CustomerMobile = "9824565333",
                CustomerAddress = "Ambikapur",
                Email = "sissy@outlook.com",
                CustomerAadharNumber = "666668589561",
                CustomerPANNumber = "SSIIO4986R",
                CustomerGender = PecuniaHelpers.Gender.Female,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();

            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Savings", Branch = "Mumbai" };
            bool isAdded1 = false;

            string errorMessage = null;

            List<RegularAccount> acc = new List<RegularAccount>();
            acc.Add(regularAccount1);

            List<RegularAccount> result = new List<RegularAccount>();
            
            List<RegularAccount> isSearched = new List<RegularAccount>();

            
            //Act
            try
            {
                isAddedcust = await customerBL.AddCustomerBL(customer);
                isAdded1 = await regularBL.CreateAccountBL(regularAccount1);
                isSearched = await regularBL.GetAccountsByBranchBL("Kolkata");

            }
            catch (Exception ex)
            {
                //isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(result,isSearched);
            }
        }


        /// <summary>
        /// Search Accounts by Account Opening Date
        /// </summary>
        [TestMethod]
        public async Task SearchAccountByAccountOpeningDate()
        {
            //Adding a new customer
            Customer customer = new Customer()
            {
                CustomerName = "Mrinal",
                CustomerMobile = "9800565444",
                CustomerAddress = "Ambikapur",
                Email = "mrinal@outlook.com",
                CustomerAadharNumber = "220068589561",
                CustomerPANNumber = "SSIIQ1086R",
                CustomerGender = PecuniaHelpers.Gender.Male,
                CustomerDOB = Convert.ToDateTime("1982-12-05"),
                WorkExperience = 25,
                AnnualIncome = 80000000
            };
            bool isAddedcust = false;
            CustomerBL customerBL = new CustomerBL();


            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount1 = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Savings", Branch = "Mumbai" };
            bool isAdded1 = false;

            RegularAccount regularAccount2 = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Savings", Branch = "Bengaluru" };
            bool isAdded2 = false;

            RegularAccount regularAccount3 = new RegularAccount() { CustomerID = customer.CustomerID, AccountType = "Current", Branch = "Mumbai" };
            bool isAdded3 = false;

            string errorMessage = null;

            List<RegularAccount> result = new List<RegularAccount>();
            result.Add(regularAccount1);
            result.Add(regularAccount2);
            result.Add(regularAccount3);

            List<RegularAccount> isSearched = new List<RegularAccount>();
            //Act
            try
            {
                isAddedcust = await customerBL.AddCustomerBL(customer);
                isAdded1 = await regularBL.CreateAccountBL(regularAccount1);
                isAdded2 = await regularBL.CreateAccountBL(regularAccount2);
                isAdded3 = await regularBL.CreateAccountBL(regularAccount3);
                isSearched = await regularBL.GetAccountsByAccountOpeningDateBL(Convert.ToDateTime("2019/10/07"), Convert.ToDateTime("2019/10/08"));

            }
            catch (Exception ex)
            {
                isSearched = null;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                CollectionAssert.Equals(isSearched, result);
            }
        }

    }
}




