﻿using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pecunia.BusinessLayer;
using Pecunia.Entities;


namespace Pecunia.UnitTest
{
    [TestClass]
    public class DebitCardBLTest
    {
        [TestMethod]
        public async Task AddValidDebitCard()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "Scott", CardType = "VISA", CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await debitCardBL.AddDebitCardBL(debitCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Name on debit card can't be null
        /// </summary>
        [TestMethod]
        public async Task NameOnDebitCardCanNotBeNull()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = null, CardType = "VISA", CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await debitCardBL.AddDebitCardBL(debitCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        /// <summary>
        /// DebitCard type can't be null
        /// </summary>
        [TestMethod]
        public async Task DebitCardTypeCanNotBeNull()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "Tarun", CardType = null, CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await debitCardBL.AddDebitCardBL(debitCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// DebitCard Status can't be null
        /// </summary>
        [TestMethod]
        public async Task DebitCardStatusCanNotBeNull()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "John", CardType = "VISA", CardStatus = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await debitCardBL.AddDebitCardBL(debitCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Name on Debit card should contain at least two characters
        /// </summary>
        [TestMethod]
        public async Task NameOnDebitCardShouldContainAtLeastTwoCharacters()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "J", CardType = "VISA", CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await debitCardBL.AddDebitCardBL(debitCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        /// <summary>
        /// DebitCard type should be valid
        /// </summary>
        [TestMethod]
        public async Task DebitCardTypeShouldBeValid()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "Asmitha", CardType = "Random", CardStatus = "Active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await debitCardBL.AddDebitCardBL(debitCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        /// <summary>
        /// DebitCard status should be valid
        /// </summary>
        [TestMethod]
        public async Task DebitCardStatusShouldBeValid()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "Asmitha", CardType = "VISA", CardStatus = "Not active" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await debitCardBL.AddDebitCardBL(debitCard);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
        ///// <summary>
        ///// Update Debit card Status
        ///// </summary>
        //[TestMethod]
        //public async Task UpdateDebitCardStatus()
        //{
        //    //Arrange
        //    DebitCardBL debitCardBL = new DebitCardBL();
        //    DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "John", CardType = "VISA", CardStatus = "Active" };
        //    await debitCardBL.AddDebitCardBL(debitCard);
        //    DebitCard debitCard1 = new DebitCard() { CardStatus = "Blocked", CardNumber = debitCard.CardNumber };



        //    bool isUpdated = false;
        //    string errorMessage = null;

        //    //Act
        //    try
        //    {
        //        isUpdated = await debitCardBL.UpdateDebitCardStatusBL(debitCard1);
        //    }
        //    catch (Exception ex)
        //    {
        //        isUpdated = false;
        //        errorMessage = ex.Message;
        //    }
        //    finally
        //    {
        //        //Assert
        //        Assert.IsTrue(isUpdated, errorMessage);
        //    }
        //}
        ///// <summary>
        ///// Update Debit card Status which is valid
        ///// </summary>
        //[TestMethod]
        //public async Task StatusToBeUpdatedShouldBeValid()
        //{
        //    //Arrange
        //    DebitCardBL debitCardBL = new DebitCardBL();
        //    DebitCard debitCard = new DebitCard() { CardStatus = "Not active" };
        //    bool isUpdated = false;
        //    string errorMessage = null;

        //    //Act
        //    try
        //    {
        //        isUpdated = await debitCardBL.UpdateDebitCardStatusBL(debitCard);
        //    }
        //    catch (Exception ex)
        //    {
        //        isUpdated = false;
        //        errorMessage = ex.Message;
        //    }
        //    finally
        //    {
        //        //Assert
        //        Assert.IsFalse(isUpdated, errorMessage);
        //    }
        //}
        /// <summary>
        /// Get DebitCard if Debit Card number is valid
        /// </summary>
        [TestMethod]
        public async Task ValidDebitCardByCardNumber()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "John", CardType = "VISA", CardStatus = "Active" };
            await debitCardBL.AddDebitCardBL(debitCard);
            bool isValid = false;
            string errorMessage = null;

            //Act
            try
            {
                if (debitCard.Equals(await debitCardBL.GetDebitCardByDebitCardNumberBL(debitCard.CardNumber)))
                { isValid = true; }
            }
            catch (Exception ex)
            {
                isValid = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isValid, errorMessage);
            }
        }
        /// <summary>
        /// Show error if Debit Card number is invalid
        /// </summary>
        [TestMethod]
        public async Task InValidDebitCardByCardNumber()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "Tarunsree", CardType = "VISA", CardStatus = "Active" };
            await debitCardBL.AddDebitCardBL(debitCard);
            string cardNumber = "000000000000";
            bool isValid = true;
            string errorMessage = null;

            //Act
            try
            {
                if ((debitCard = (await debitCardBL.GetDebitCardByDebitCardNumberBL(cardNumber))) == null)
                {
                    isValid = false;
                }
            }
            catch (Exception ex)
            {
                isValid = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isValid, errorMessage);
            }
        }
        /// <summary>
        ///Update debit card status
        /// </summary>
        [TestMethod]
        public async Task UpdateDebitCardStatus()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            bool isAdded = false;

            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "Tarunsree", CardType = "VISA", CardStatus = "Active" };
            isAdded = await debitCardBL.AddDebitCardBL(debitCard);

            bool isUpdated = false;
            string errorMessage = null;
            //Act
            try
            {

                DebitCard debitCard1 = new DebitCard() { DebitCardID = debitCard.DebitCardID, CardNumber = debitCard.CardNumber, CustomerNameAsPerCard = "Tarunsree", CardType = "VISA", CardStatus = "Active", ExpiryMMYYYY = "10/24", CardIssueDate = debitCard.CardIssueDate, LastModifiedDate = debitCard.LastModifiedDate };
                isUpdated = await debitCardBL.UpdateDebitCardStatusBL(debitCard1);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }
        /// <summary>
        ///
        /// </summary>
        [TestMethod]
        public async Task UpdateDebitCardStatusError()
        {
            //Arrange
            DebitCardBL debitCardBL = new DebitCardBL();
            bool isAdded = false;

            DebitCard debitCard = new DebitCard() { CustomerNameAsPerCard = "Tarunsree", CardType = "VISA", CardStatus = "Active" };
            isAdded = await debitCardBL.AddDebitCardBL(debitCard);

            bool isUpdated = true;
            string errorMessage = null;
            //Act
            try
            {

                DebitCard debitCard1 = new DebitCard() { DebitCardID = debitCard.DebitCardID, CardNumber = "000000000000", CustomerNameAsPerCard = "Tarunsree", CardType = "VISA", CardStatus = "Active", ExpiryMMYYYY = "10/24" };
                isUpdated = await debitCardBL.UpdateDebitCardStatusBL(debitCard1);
            }
            catch (Exception ex)
            {
                isUpdated = true;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }
    }
}

