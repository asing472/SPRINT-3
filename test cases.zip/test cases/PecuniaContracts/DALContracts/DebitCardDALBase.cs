﻿using Pecunia.Entities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.DALContracts
{
    /// <summary>
    /// This abstract class acts as a base class for DebitCardDAL class
    /// </summary>
    public abstract class DebitCardDALBase
    {
        public static List<DebitCard> debitCardsList = new List<DebitCard>();

        private static string fileName = "debitCards.json";

        //Methods for CRUD operations
        public abstract bool AddDebitCardDAL(DebitCard debitCard);
        public abstract List<DebitCard> GetDebitCardListDAL();
        public abstract bool UpdateDebitCardStatusDAL(DebitCard updateDebitCard);
        public abstract List<DebitCard> GetDebitCardsByAccountIDDAL(Guid accountID);
        public abstract DebitCard GetDebitCardByDebitCardNumberDAL(string debitCardNumber);
        /// <summary>
        /// Writes collection to the file in JSON format.
        /// </summary>
        public void Serialize()
        {
            string serializedJson = JsonConvert.SerializeObject(debitCardsList);
            using (StreamWriter streamWriter = new StreamWriter(fileName))
            {
                streamWriter.Write(serializedJson);
                streamWriter.Close();
            }
        }


        /// <summary>
        /// Reads collection from the file in JSON format.
        /// </summary>
        public void Deserialize()
        {
            string fileContent = string.Empty;
            if (!File.Exists(fileName))
                File.Create(fileName).Close();

            using (StreamReader streamReader = new StreamReader(fileName))
            {
                fileContent = streamReader.ReadToEnd();
                streamReader.Close();
                var debitCardsListFromFile = JsonConvert.DeserializeObject<List<DebitCard>>(fileContent);
                if (debitCardsListFromFile != null)
                {
                    debitCardsList = debitCardsListFromFile;
                }
            }
        }


        /// <summary>
        /// Static Constructor.
        /// </summary>
        public DebitCardDALBase()
        {
            Deserialize();


        }




    }
}
