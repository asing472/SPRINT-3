﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Contracts.BLContracts;
using Pecunia.DataAcessLayer;
using Pecunia.Contracts.DALContracts;
using Pecunia.Exceptions;

namespace Pecunia.BusinessLayer
{
    public class CarLoanBL : BLBase<CarLoan>, ICarLoanBL, IDisposable
    {
        //fields
        CarLoanDALBase carloanDAL;

        /// <summary>
        /// Class Constructor.
        /// </summary>
        public CarLoanBL()
        {
            this.carloanDAL = new CarLoanDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>
        protected async override Task<bool> Validate(CarLoan entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //Loan Should be greater than 0
            if (entityObject.AmtOfLoan <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Amount of loan should be greater than 0");
            }

            //Duration Should be Greater Than 0
            if (entityObject.Tenure <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Duration of loan should be greater than 0");
            }

            //Customer is Unique
            var existingObject = carloanDAL.GetCarLoanByCustomerDAL(entityObject.CustomerNumber);
            if (existingObject != null && existingObject?.LoanNumber != entityObject.LoanNumber)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Customer {entityObject.CustomerNumber} already exists");
            }
            //License is Unique
            var existingObject1 = carloanDAL.GetCarLoanByLicenseDAL(entityObject.License);
            if (existingObject1 != null && existingObject1?.LoanNumber != entityObject.LoanNumber)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"License {entityObject.CustomerNumber} already exists");
            }
            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Add new car loan to car loans collection.
        /// </summary>
        /// <param name="newCarLoan">Contains the car loan details to be added.</param>
        /// <returns>Determinates whether the new car loan is added.</returns>
        public async Task<bool> AddCarLoanBL(CarLoan newCarLoan)
        {
            bool LoanAdded = false;
            try
            {
                //CustomerBL cbl = new CustomerBL();

                //Customer cust = await cbl.GetCustomerByCustomerNumberBL(newCarLoan.CustomerNumber);
                //if (cust != null)
                //{


                if (await Validate(newCarLoan))
                {
                    await Task.Run(() =>
                    {

                        LoanAdded = carloanDAL.AddCarLoanDAL(newCarLoan);

                    });
                }
                //}


            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }


        /// <summary>
        /// Gets all car loan from the collection.
        /// </summary>
        /// <returns>Returns list of all car loan collection.</returns>
        public async Task<List<CarLoan>> GetAllCarLoanBL()
        {
            List<CarLoan> CarsList = null;
            try
            {
                await Task.Run(() =>
                {
                    CarsList = carloanDAL.GetAllCarLoanDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return CarsList;
        }

        /// <summary>
        /// Return Car loan details based on loan number
        /// </summary>
        /// <param name="LoanNumber"></param>
        /// <returns></returns>
        public async Task<CarLoan> GetCarLoanByLoanNumberBL(string LoanNumber)
        {
            CarLoan carloan = null;
            try
            {
                await Task.Run(() =>
                {
                    carloan = carloanDAL.GetCarLoanByLoanNumberDAL(LoanNumber);
                });
                if (carloan == null)
                {
                    await Validate(carloan);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return carloan;
        }

        /// <summary>
        /// Will return Loan details based on loan status
        /// </summary>
        /// <param name="LoanStatus"></param>
        /// <returns>Return List of Loan Status</returns>
        public async Task<List<CarLoan>> GetCarLoanByLoanStatusBL(string LoanStatus)
        {
            List<CarLoan> carloan = null;
            try
            {
                await Task.Run(() =>
                {
                    carloan = carloanDAL.GetCarLoanByLoanStatusDAL(LoanStatus);
                });

            }
            catch (Exception)
            {
                throw;
            }
            return carloan;
        }

        /// <summary>
        /// Will Update Car Loan
        /// </summary>
        /// <param name="updatedloan"></param>
        /// <returns>Will Return wether loan is updted or not</returns>
        public async Task<bool> UpdateCarLoanBL(CarLoan updatedloan)
        {
            bool Updated = false;
            try
            {
                if ((await Validate(updatedloan)) && (carloanDAL.GetCarLoanByLoanNumberDAL(updatedloan.LoanNumber)) != null)
                {

                    Updated = carloanDAL.UpdateCarLoanDAL(updatedloan);

                }
            }
            catch (Exception)
            {
                throw;
            }
            return Updated;
        }

        /// <summary>
        /// Delete Car Loan based on LoanNumber
        /// </summary>
        /// <param name="LoanNumber"></param>
        /// <returns>Will return based on loan is deleted or not</returns>
        public async Task<bool> DeleteCarLoanBL(string LoanNumber)
        {
            {
                bool loandeleted = false;
                try
                {
                    CarLoan carloan = await GetCarLoanByLoanNumberBL(LoanNumber);
                    if (await Validate(carloan) && carloan != null)
                    {
                        await Task.Run(() =>
                        {

                            loandeleted = carloanDAL.DeleteCarLoanDAL(LoanNumber);
                        });
                    }



                }
                catch (Exception)
                {
                    throw;
                }
                return loandeleted;
            }
        }

        /// <summary>
        /// Calculate wether loan is approved or not
        /// </summary>
        /// <param name="LoanNumber"></param>
        /// <returns>will return Loan Status</returns>
        public async Task<bool> CarLoanEligibilityBL(string LoanNumber)
        {
            {
                bool loaneligible = false;
                CarLoan carloan = await GetCarLoanByLoanNumberBL(LoanNumber);
                await Validate(carloan);
                try
                {
                    await Task.Run(() =>
                    {
                        loaneligible = carloanDAL.GetCarEligibility(LoanNumber);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loaneligible;
            }
        }



        /// <summary>
        /// Memory Managment
        /// </summary>
        public void Dispose()
        {
            ((CarLoanDAL)carloanDAL).Dispose();
        }
    }
    public class HomeLoanBL : BLBase<HomeLoan>, IHomeLoanBL, IDisposable
    {
        //fields
        HomeLoanDALBase homeloanDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public HomeLoanBL()
        {
            this.homeloanDAL = new HomeLoanDAL();

        }

        /// <summary>
        /// To validate the new loan added or updated
        /// </summary>
        /// <param name="entityObject"></param>
        /// <returns>Validated Loan</returns>
        protected async override Task<bool> Validate(HomeLoan entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //LoanNumber exist
            //var existingObject2 = homeloanDAL.GetHomeLoanByLoanNumberDAL(entityObject.LoanNumber);
            //if (existingObject2 == null)
            //{
            //    valid = false;
            //    sb.Append(Environment.NewLine + $"Loan {entityObject.CustomerNumber} does'nt exists");
            //}

            if (entityObject.AmtOfLoan <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Amount of loan should be greater than 0");
            }

            if (entityObject.Tenure <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Duration of loan should be greater than 0");
            }
            if (entityObject.Collateral <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + " loan Collateral should be greater than 0");
            }

            //Email is Unique
            var existingObject = homeloanDAL.GetHomeLoanByCustomerDAL(entityObject.CustomerNumber);
            if (existingObject != null && existingObject?.LoanNumber != entityObject.LoanNumber)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Customer {entityObject.CustomerNumber} already exists");
            }

            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new Home loan to Home Loan collection.
        /// </summary>
        /// <param name="newHomeLoan">Contains the Home Loan details to be added.</param>
        /// <returns>Determinates whether the new Home Loan  is added.</returns>
        public async Task<bool> AddHomeLoanBL(HomeLoan newHomeLoan)
        {
            bool LoanAdded = false;
            try
            {
                CustomerBL cbl = new CustomerBL();
                //newHomeLoan.CustomerNumber
                Customer cust = await cbl.GetCustomerByCustomerNumberBL(newHomeLoan.CustomerNumber);
                if (cust != null)
                {
                    if (await Validate(newHomeLoan))
                    {
                        await Task.Run(() =>
                        {

                            LoanAdded = homeloanDAL.AddHomeLoanDAL(newHomeLoan);

                        });
                    }
                }

            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }


        /// <summary>
        /// Gets all Home Loan Details from the collection.
        /// </summary>
        /// <returns>Returns list of all home loan details.</returns>
        public async Task<List<HomeLoan>> GetAllHomeLoanBL()
        {
            List<HomeLoan> HomeList = null;
            try
            {
                await Task.Run(() =>
                {
                    HomeList = homeloanDAL.GetAllHomeLoanDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return HomeList;
        }

        /// <summary>
        /// Return loan details based on loan number
        /// </summary>
        /// <param name="loannumber"></param>
        /// <returns></returns>
        public async Task<HomeLoan> GetHomeLoanByLoanNumberBL(string loannumber)
        {
            HomeLoan homeloan = null;
            try
            {
                await Task.Run(() =>
                {
                    homeloan = homeloanDAL.GetHomeLoanByLoanNumberDAL(loannumber);
                });
                if (homeloan == null)
                {
                    await Validate(homeloan);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return homeloan;
        }

        /// <summary>
        /// Will return home loan details list  based on status
        /// </summary>
        /// <param name="LoanStatus"></param>
        /// <returns></returns>
        public async Task<List<HomeLoan>> GetHomeLoanByLoanStatusBL(string LoanStatus)
        {
            List<HomeLoan> Homeloan = null;
            try
            {
                await Task.Run(() =>
                {
                    Homeloan = homeloanDAL.GetHomeLoanByLoanStatusDAL(LoanStatus);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return Homeloan;
        }

        /// <summary>
        /// Will Update Education Loan
        /// </summary>
        /// <param name="updatedloan"></param>
        /// <returns></returns>
        public async Task<bool> UpdateHomeLoanBL(HomeLoan updatedloan)
        {
            bool Updated = false;
            try
            {
                if ((await Validate(updatedloan)) && (await GetHomeLoanByLoanNumberBL(updatedloan.LoanNumber)) != null)
                {

                    Updated = homeloanDAL.UpdateHomeLoanDAL(updatedloan);

                }
            }
            catch (Exception)
            {
                throw;
            }
            return Updated;
        }

        /// <summary>
        /// Will delete home loan based on home loan number
        /// </summary>
        /// <param name="deleteLoannumber"></param>
        /// <returns></returns>
        public async Task<bool> DeleteHomeLoanBL(string deleteLoannumber)
        {
            {
                bool loandeleted = false;
                try
                {
                    HomeLoan homeloan = await GetHomeLoanByLoanNumberBL(deleteLoannumber);
                    await Validate(homeloan);
                    await Task.Run(() =>
                    {
                        loandeleted = homeloanDAL.DeleteHomeLoanDAL(deleteLoannumber);
                    });

                }
                catch (Exception)
                {
                    throw;
                }
                return loandeleted;
            }
        }

        /// <summary>
        ///Will return wether person is eligible for loan or not 
        /// </summary>
        /// <param name="LoanNumber"></param>
        /// <returns></returns>
        public async Task<bool> HomeLoanEligibilityBL(string LoanNumber)
        {
            {
                bool loaneligible = false;
                HomeLoan homeloan = await GetHomeLoanByLoanNumberBL(LoanNumber);
                await Validate(homeloan);
                try
                {
                    await Task.Run(() =>
                    {
                        loaneligible = homeloanDAL.GetHomeEligibility(LoanNumber);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loaneligible;
            }
        }

        /// <summary>
        /// To serialize home loan
        /// </summary>
        /// <returns></returns>
        public async Task<bool> HomeSerialize()
        {
            bool serialized = false;
            try
            {
                await Task.Run(() =>
                {
                    homeloanDAL.Homeserialize();
                    serialized = true;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return serialized;
        }

        /// <summary>
        /// Memory managment
        /// </summary>
        public void Dispose()
        {
            ((HomeLoanDAL)homeloanDAL).Dispose();
        }
    }
    public class PersonalLoanBL : BLBase<PersonalLoan>, IPersonalLoanBL, IDisposable
    {
        //fields
        PersonalLoanDALBase personalloanDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public PersonalLoanBL()
        {
            this.personalloanDAL = new PersonalLoanDAL();
        }
        /// <summary>
        /// To validate Home Loan details before adding or updating 
        /// </summary>
        /// <param name="entityObject"></param>
        /// <returns></returns>
        protected async override Task<bool> Validate(PersonalLoan entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            if (entityObject.AmtOfLoan <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Amount of loan should be greater than 0");
            }

            if (entityObject.Tenure <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Duration of loan should be greater than 0");
            }
            if (entityObject.Collateral <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + " loan Collateral should be greater than 0");
            }
            ////LoanNumber exist
            //var existingObject2 = personalloanDAL.GetPersonalLoanByLoanNumberDAL(entityObject.LoanNumber);
            //if (existingObject2 == null)
            //{
            //    valid = false;
            //    sb.Append(Environment.NewLine + $"Loan {entityObject.CustomerNumber} does'nt exists");
            //}
            ////Email is Unique
            //var existingObject = personalloanDAL.GetPersonalLoanByCustomerDAL(entityObject.CustomerNumber);
            //if (existingObject != null && existingObject?.LoanNumber != entityObject.LoanNumber)
            //{
            //    valid = false;
            //    sb.Append(Environment.NewLine + $"Customer {entityObject.CustomerNumber} already exists");
            //}

            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new Personal Loan to Personal Loan List collection.
        /// </summary>
        /// <param name="newPersonalLoan">Contains the supplier details to be added.</param>
        /// <returns>Determines whether the new supplier is added.</returns>
        public async Task<bool> AddPersonalLoanBL(PersonalLoan newPersonalLoan)
        {
            bool LoanAdded = false;
            try
            {

                //CustomerBL cbl = new CustomerBL();
                //Customer cust = await cbl.GetCustomerByCustomerNumberBL(newPersonalLoan.CustomerNumber);
                //if (cust != null)
                //{
                if (await Validate(newPersonalLoan))
                {
                    await Task.Run(() =>
                    {

                        LoanAdded = personalloanDAL.AddPersonalLoanDAL(newPersonalLoan);

                    });
                }
                //}

            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }


        /// <summary>
        /// Gets all Personal loan details from the list.
        /// </summary>
        /// <returns>Returns list of all personal details.</returns>
        public async Task<List<PersonalLoan>> GetAllPersonalLoanBL()
        {
            List<PersonalLoan> personalList = null;
            try
            {
                await Task.Run(() =>
                {
                    personalList = personalloanDAL.GetAllPersonalLoanDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return personalList;
        }

        /// <summary>
        /// Return Personal Number based on Loan Number
        /// </summary>
        /// <param name="loannumber"></param>
        /// <returns>Retun Personal Loan Details based on Loan Number</returns>
        public async Task<PersonalLoan> GetPersonalLoanByLoanNumberBL(string loannumber)
        {
            PersonalLoan personalloan = null;
            try
            {
                await Task.Run(() =>
                {
                    personalloan = personalloanDAL.GetPersonalLoanByLoanNumberDAL(loannumber);
                });
                if (personalloan == null)
                {
                    await Validate(personalloan);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return personalloan;
        }

        /// <summary>
        /// Returns List Based On Loan Status
        /// </summary>
        /// <param name="LoanStatus"></param>
        /// <returns>Returns List </returns>
        public async Task<List<PersonalLoan>> GetPersonalLoanByLoanStatusBL(string LoanStatus)
        {
            List<PersonalLoan> personalloan = null;
            try
            {
                await Task.Run(() =>
                {
                    personalloan = personalloanDAL.GetPersonalLoanByLoanStatusDAL(LoanStatus);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return personalloan;
        }

        /// <summary>
        /// Updates Personal Number Based on Loan Number
        /// </summary>
        /// <param name="updatedloan"></param>
        /// <returns>Updates Loan</returns>
        public async Task<bool> UpdatePersonalLoanBL(PersonalLoan updatedloan)
        {
            bool Updated = false;
            try
            {
                if ((await Validate(updatedloan)) && (await GetPersonalLoanByLoanNumberBL(updatedloan.LoanNumber)) != null)
                {

                    Updated = personalloanDAL.UpdatePersonalLoanDAL(updatedloan);

                }
            }
            catch (Exception)
            {
                throw;
            }
            return Updated;
        }

        /// <summary>
        /// Deletes personal loan Based On loan number 
        /// </summary>
        /// <param name="deleteLoannumber"></param>
        /// <returns></returns>
        public async Task<bool> DeletePersonalLoanBL(string deleteLoannumber)
        {
            {
                bool loandeleted = false;
                try
                {
                    PersonalLoan perloan = await GetPersonalLoanByLoanNumberBL(deleteLoannumber);
                    await Validate(perloan);
                    await Task.Run(() =>
                    {
                        loandeleted = personalloanDAL.DeletePersonalLoanDAL(deleteLoannumber);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loandeleted;
            }
        }

        /// <summary>
        /// Check Wether Person is Eligible for Loan or not
        /// </summary>
        /// <param name="LoanNumber"></param>
        /// <returns></returns>
        public async Task<bool> PersonalLoanEligibilityBL(string LoanNumber)
        {
            {
                bool loaneligible = false;
                try
                {
                    PersonalLoan perloan = await GetPersonalLoanByLoanNumberBL(LoanNumber);
                    await Validate(perloan);
                    await Task.Run(() =>
                    {
                        loaneligible = personalloanDAL.GetPersonalEligibility(LoanNumber);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loaneligible;
            }
        }

        /// <summary>
        /// To Serialise Personal Loan Details
        /// </summary>
        /// <returns></returns>
        public async Task<bool> PersonalSerialize()
        {
            bool serialized = false;
            try
            {
                await Task.Run(() =>
                {
                    personalloanDAL.Personalserialize();
                    serialized = true;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return serialized;
        }

        /// <summary>
        /// Memory Managment
        /// </summary>
        public void Dispose()
        {
            ((PersonalLoanDAL)personalloanDAL).Dispose();
        }
    }

    public class EducationLoanBL : BLBase<EducationLoan>, IEducationLoanBL, IDisposable
    {
        //fields
        EducationLoanDALBase educationloanDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public EducationLoanBL()
        {
            this.educationloanDAL = new EducationLoanDAL();
        }

        /// <summary>
        /// Validates Loan before adding or updating 
        /// </summary>
        /// <param name="entityObject"></param>
        /// <returns></returns>
        protected async override Task<bool> Validate(EducationLoan entityObject)
        {
            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            if (entityObject.AmtOfLoan <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Amount of loan should be greater than 0");
            }

            if (entityObject.Tenure <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + "Duration of loan should be greater than 0");
            }
            if (entityObject.Collateral <= 0)
            {
                valid = false;
                sb.Append(Environment.NewLine + " loan Collateral should be greater than 0");
            }

            ////LoanNumber exist
            //var existingObject2 = educationloanDAL.GetEducationLoanByLoanNumberDAL(entityObject.LoanNumber);
            //if (existingObject2 == null)
            //{
            //    valid = false;
            //    sb.Append(Environment.NewLine + $"Loan {entityObject.CustomerNumber} does'nt exists");
            //}

            ////Customer Number
            //var existingObject = educationloanDAL.GetEduLoanByCustomerDAL(entityObject.CustomerNumber);
            //if (existingObject != null && existingObject?.LoanNumber != entityObject.LoanNumber)
            //{
            //    valid = false;
            //    sb.Append(Environment.NewLine + $"Customer {entityObject.CustomerNumber} already exists");
            //}

            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;
        }

        /// <summary>
        /// Adds new  Education Loan to Education Loan collection.
        /// </summary>
        /// <param name="neweducationLoan">Contains the Education Loan details to be added.</param>
        /// <returns>Determinates whether the new Education Loan is added.</returns>
        public async Task<bool> AddEducationLoanBL(EducationLoan neweducationLoan)
        {
            bool LoanAdded = false;
            try
            {
                CustomerBL cbl = new CustomerBL();

                Customer cust = await cbl.GetCustomerByCustomerNumberBL(neweducationLoan.CustomerNumber);
                if (cust != null)
                {
                    if (await Validate(neweducationLoan))
                    {
                        await Task.Run(() =>
                        {

                            LoanAdded = educationloanDAL.AddEducationLoanDAL(neweducationLoan);

                        });
                    }
                }
            }
            catch (Exception)
            {
                throw;
            }
            return LoanAdded;
        }


        /// <summary>
        /// Gets all Education Loan from the collection.
        /// </summary>
        /// <returns>Returns list of all Education Loan.</returns>
        public async Task<List<EducationLoan>> GetAllEducationLoanBL()
        {
            List<EducationLoan> educationList = null;
            try
            {
                await Task.Run(() =>
                {
                    educationList = educationloanDAL.GetAllEducationLoanDAL();
                });
            }
            catch (Exception)
            {
                throw;
            }
            return educationList;
        }

        /// <summary>
        /// Get Education Loan Based on Loan Number
        /// </summary>
        /// <param name="loannumber">Unique Loan ID</param>
        /// <returns>Loan Details based on loan number </returns>
        public async Task<EducationLoan> GetEducationLoanByLoanNumberBL(string loannumber)
        {
            EducationLoan educationloan = null;
            try
            {
                await Task.Run(() =>
                {
                    educationloan = educationloanDAL.GetEducationLoanByLoanNumberDAL(loannumber);

                });
                if (educationloan == null)
                {
                    await Validate(educationloan);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return educationloan;
        }

        /// <summary>
        /// Get Education Loan list based on status
        /// </summary>
        /// <param name="LoanStatus">Approved Rejected Pending</param>
        /// <returns>Returns List Of Education details</returns>
        public async Task<List<EducationLoan>> GetEducationLoanByLoanStatusBL(string LoanStatus)
        {
            List<EducationLoan> educationloan = null;
            try
            {
                await Task.Run(() =>
                {
                    educationloan = educationloanDAL.GetEducationLoanByLoanStatusDAL(LoanStatus);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return educationloan;
        }

        /// <summary>
        /// Update Education Loan
        /// </summary>
        /// <param name="updatedloan">Contain details of all education loan</param>
        /// <returns></returns>
        public async Task<bool> UpdateEducationLoanBL(EducationLoan updatedloan)
        {
            bool Updated = false;
            try
            {
                if ((await Validate(updatedloan)) && (await GetEducationLoanByLoanNumberBL(updatedloan.LoanNumber)) != null)
                {

                    Updated = educationloanDAL.UpdateEducationLoanDAL(updatedloan);

                }
            }
            catch (Exception)
            {
                throw;
            }
            return Updated;
        }

        /// <summary>
        /// Delets All Education Loan based on loan number
        /// </summary>
        /// <param name="deleteLoanID"></param>
        /// <returns></returns>
        public async Task<bool> DeleteEducationLoanBL(string deleteLoanID)
        {
            {
                bool loandeleted = false;
                try
                {
                    EducationLoan eduloan = await GetEducationLoanByLoanNumberBL(deleteLoanID);
                    await Validate(eduloan);
                    await Task.Run(() =>
                    {
                        loandeleted = educationloanDAL.DeleteEducationLoanDAL(deleteLoanID);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loandeleted;
            }
        }

        /// <summary>
        /// Check Wether Person is eligible for loan or not
        /// </summary>
        /// <param name="LoanNumber"></param>
        /// <returns></returns>
        public async Task<bool> EducationLoanEligibilityBL(string LoanNumber)
        {
            {
                bool loaneligible = false;
                try
                {
                    EducationLoan eduloan = await GetEducationLoanByLoanNumberBL(LoanNumber);
                    await Validate(eduloan);
                    await Task.Run(() =>
                    {
                        loaneligible = educationloanDAL.GetEducationEligibility(LoanNumber);
                    });
                }
                catch (Exception)
                {
                    throw;
                }
                return loaneligible;
            }
        }

        /// <summary>
        /// To serialise Education Loan
        /// </summary>
        /// <returns></returns>
        public async Task<bool> EducationSerialize()
        {
            bool serialized = false;
            try
            {
                await Task.Run(() =>
                {
                    educationloanDAL.Educationserialize();
                    serialized = true;
                });
            }
            catch (Exception)
            {
                throw;
            }
            return serialized;
        }

        /// <summary>
        /// Memory Managment
        /// </summary>
        public void Dispose()
        {
            ((EducationLoanDAL)educationloanDAL).Dispose();
        }
    }

}
