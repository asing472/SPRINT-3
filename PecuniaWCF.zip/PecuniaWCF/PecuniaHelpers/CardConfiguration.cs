﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Helpers
{
    /// <summary>
    /// Assigning starting and default value to accounts
    /// </summary>
    public class CardConfiguration
    {
        public static long baseDebitCardNumber = 100010001000;
        public static long baseCreditCardNumber = 200020002000;

    }
}
