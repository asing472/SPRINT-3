﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Contracts.DALContracts;

namespace Pecunia.DataAcessLayer
{
    public class TransactionsDAL : TransactionDALBase, IDisposable
    {

        public override bool AddTransactionDAL(Transaction newTransaction)
        {
            bool TransactionDone = false;
            try
            {
                RegularAccountDAL account = new RegularAccountDAL();

                newTransaction.TransactionID = Guid.NewGuid();
                newTransaction.TransactionDateTime = DateTime.Now;
                if (newTransaction.TransactionType.Equals("Credit", StringComparison.OrdinalIgnoreCase))
                {
                    double balance = account.GetBalanceDAL(newTransaction.CreditAccountNumber);
                    balance += newTransaction.Ammount;
                    account.UpdateBalanceDAL(newTransaction.CreditAccountNumber, balance);
                }
                if (newTransaction.TransactionType.Equals("Debit", StringComparison.OrdinalIgnoreCase))
                {
                    double balance = account.GetBalanceDAL(newTransaction.DebitAccountNumber);
                    balance -= newTransaction.Ammount;
                    account.UpdateBalanceDAL(newTransaction.DebitAccountNumber, balance);
                }
                if (newTransaction.TransactionType.Equals("Transfer", StringComparison.OrdinalIgnoreCase))
                {
                    double debitBalance = account.GetBalanceDAL(newTransaction.DebitAccountNumber);
                    debitBalance -= newTransaction.Ammount;
                    account.UpdateBalanceDAL(newTransaction.DebitAccountNumber, debitBalance);
                    double creditBalance = account.GetBalanceDAL(newTransaction.CreditAccountNumber);
                    creditBalance += newTransaction.Ammount;
                    account.UpdateBalanceDAL(newTransaction.DebitAccountNumber, creditBalance);
                }
                newTransaction.TransactionID = Guid.NewGuid();
                newTransaction.TransactionDateTime = DateTime.Now;
                TransactionList.Add(newTransaction);
                TransactionDone = true;

            }
            catch (Exception)
            {
                throw;
            }
            return TransactionDone;
        }

        public override List<Transaction> GetAllTransactionsDAL()
        {
            return TransactionList;
        }
        public override List<Transaction> GetAllTransactionsByTransactionTypeDAL(string TransactionType)
        {
            List<Transaction> matchingTransactions = new List<Transaction>();
            try
            {

                matchingTransactions = TransactionList.FindAll(
                    (item) => { return item.TransactionType.Equals(TransactionType, StringComparison.OrdinalIgnoreCase); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingTransactions;
        }

        public override List<Transaction> GetAllTransactionsByAccountNumberDAL(string accountNumber)
        {
            List<Transaction> matchingTransactions = new List<Transaction>();
            try
            {

                matchingTransactions = TransactionList.FindAll(
                    (item) => { return (item.CreditAccountNumber.Equals(accountNumber, StringComparison.OrdinalIgnoreCase)) || (item.DebitAccountNumber.Equals(accountNumber, StringComparison.OrdinalIgnoreCase)); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingTransactions;
        }
        public override List<Transaction> GetAllTransactionsByTimeDAL(DateTime TransactionDateTime)
        {
            List<Transaction> matchingTransactions = new List<Transaction>();
            try
            {

                matchingTransactions = TransactionList.FindAll(
                    (item) => { return item.TransactionDateTime.Equals(TransactionDateTime); }
                );
            }
            catch (Exception)
            {
                throw;
            }
            return matchingTransactions;
        }

        public void Dispose() { }
    }

}
