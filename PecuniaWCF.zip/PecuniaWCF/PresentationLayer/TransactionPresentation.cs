﻿using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;


namespace Pecunia.PresentationLayer
{
    class TransactionPresentation
    {
        public static async Task<int> TransactionMenu()
        {
            int choice = -1;
            do
            {

                WriteLine("\n1. Add  New Debit Transaction");
                WriteLine("2. Add  New Credit Transaction");
                WriteLine("3. Account Transfer");
                WriteLine("4. See All Transactions for an account type");
                WriteLine("5. See All Transactions for an account number");
                //WriteLine("6. See All Transactions for a date");
                WriteLine("-----------------------");
                WriteLine("0. Exit");
                Write("Choice: ");

                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1: await Debit(); break;
                        case 2: await Credit(); break;
                        case 3: await Transfer(); break;
                        case 4: await TransactionByType(); break;
                        case 5: await TransactionAccountNumber(); break;

                        
                        case 0: break;

                        default: WriteLine("Invalid Choice"); break;
                    }
                }
                else
                {
                    choice = -1;
                }
            } while (choice != 0 && choice != -1);
            return choice;
        }
        public static async Task Debit()
        {
            Transaction transaction = new Transaction();
            Write("Account Number");
            transaction.DebitAccountNumber = ReadLine();
            Write("Ammount");
            transaction.Ammount = Convert.ToDouble(ReadLine());
            transaction.TransactionType = "Debit";
            using (ITransactionsBL transactionsBL = new TransactionsBL())
            {
                bool isAdded = await transactionsBL.AddTransactionBL(transaction);
                if (isAdded)
                {
                    WriteLine("Transacton Done");
                }
            }
        }
        public static async Task Credit()
        {
            Transaction transaction = new Transaction();
            Write("Account Number");
            transaction.DebitAccountNumber = ReadLine();
            Write("Ammount");
            transaction.Ammount = Convert.ToDouble(ReadLine());
            transaction.TransactionType = "Credit";
            using (ITransactionsBL transactionsBL = new TransactionsBL())
            {
                bool isAdded = await transactionsBL.AddTransactionBL(transaction);
                if (isAdded)
                {
                    WriteLine("Transacton Done");
                }
            }
        }
        public static async Task Transfer()
        {
            Transaction transaction = new Transaction();
            Write(" Debuit Account Number");
            transaction.DebitAccountNumber = ReadLine();
            Write(" Credit Account Number");
            transaction.CreditAccountNumber = ReadLine();
            Write("Ammount");
            transaction.Ammount = Convert.ToDouble(ReadLine());
            transaction.TransactionType = "Transfer";
            using (ITransactionsBL transactionsBL = new TransactionsBL())
            {
                bool isAdded = await transactionsBL.AddTransactionBL(transaction);
                if (isAdded)
                {
                    WriteLine("Transacton Done");
                }
            }
        }

        public static async Task TransactionByType()
        {
            using (ITransactionsBL transactionsBL = new TransactionsBL())
            {
                List<Transaction> transaction = new List<Transaction>();
                Write("Transaction Type:");
                string type = ReadLine();
                transaction = await transactionsBL.GetAllTransactionsByTransactionTypeBL(type);

                if (transaction != null)
                {
                    if (type.Equals("Credit", StringComparison.OrdinalIgnoreCase))
                    {
                        WriteLine("Transaction ID \t\t Account Number \t\t Ammount \t\t Time");
                        foreach(var item in transaction)
                        {
                            WriteLine($"{item.TransactionID}\t\t{item.CreditAccountNumber}\t\t{item.Ammount}\t\t {item.TransactionDateTime}");
                        }
                    }
                    else if (type.Equals("Debit", StringComparison.OrdinalIgnoreCase))
                    {
                        WriteLine("Transaction ID \t\t Account Number \t\t Ammount \t\t Time");
                        foreach (var item in transaction)
                        {
                            WriteLine($"{item.TransactionID}\t\t{item.DebitAccountNumber}\t\t{item.Ammount}\t\t {item.TransactionDateTime}");
                        }
                    }
                    else if (type.Equals("Transfer", StringComparison.OrdinalIgnoreCase))
                    {
                        WriteLine("Transaction ID \t\t Credit Account Number \t\t Debit Account Number \t\t Ammount \t\t Time");
                        foreach (var item in transaction)
                        {
                            WriteLine($"{item.TransactionID}\t\t{item.CreditAccountNumber}\t\t{item.DebitAccountNumber}\t\t{item.Ammount}\t\t {item.TransactionDateTime}");
                        }
                    }

                }
            }
        }
        public static async Task TransactionAccountNumber()
        {
            using (ITransactionsBL transactionsBL = new TransactionsBL())
            {
                List<Transaction> transaction = new List<Transaction>();
                Write("Account Number:");
                string number = ReadLine();
                transaction = await transactionsBL.GetAllTransactionsByAccountNumberBL(number);
                if(transaction!= null)
                {
                    WriteLine("Transaction ID \t\tCredit Account Number \t\tDebit Account Number\t\t Ammount\t\t TransactionType \t\t Time");
                    foreach (var item in transaction)
                    {
                        WriteLine($"{item.TransactionID}\t\t{item.CreditAccountNumber}\t\t{item.DebitAccountNumber}\t\t{item.Ammount}\t\t{item.TransactionType}\t\t {item.TransactionDateTime}");
                    }
                }
            }
               

        }



    }
}
