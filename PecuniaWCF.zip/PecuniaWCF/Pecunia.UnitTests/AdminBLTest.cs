﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Threading.Tasks;
using Pecunia.BusinessLayer;
using Pecunia.Entities;
namespace Pecunia.UnitTests
{
    [TestClass]
    public class AdminLoginBLTest
    {
        [TestMethod]
        public async Task ValidLogin()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();



            //Act
            Admin admin = await adminBL.GetAdminByEmailAndPasswordBL("admin@capgemini.com", "Admin@123");

            //Assert
            Assert.IsNotNull(admin);
        }

        [TestMethod]
        public async Task InValidAdminEmail()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();



            //Act
            Admin admin = await adminBL.GetAdminByEmailAndPasswordBL("a@capgemini.com", "Admin@123");

            //Assert
            Assert.IsNull(admin);
        }
        [TestMethod]
        public async Task InValidAdminPassword()
        {
            //Arrange
            AdminBL adminBL = new AdminBL();



            //Act
            Admin admin = await adminBL.GetAdminByEmailAndPasswordBL("admin@capgemini.com", "Admin123");

            //Assert
            Assert.IsNull(admin);
        }
    }
}
