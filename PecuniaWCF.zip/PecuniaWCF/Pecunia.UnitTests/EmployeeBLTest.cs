﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Threading.Tasks;
using Pecunia.BusinessLayer;
using Pecunia.Entities;

namespace Pecunia.UnitTests
{
    [TestClass]
    public class AddEmployeeBLTest
    {
        /// <summary>
        /// Add Employee to the Collection if it is valid.
        /// </summary>
        [TestMethod]
        public async Task AddValidEmployee()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = "Taklikar", Password = "Taklikar123#", Email = "taklikar@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(employee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Employee Name can't be null
        /// </summary>
        [TestMethod]
        public async Task EmployeeNameCanNotBeNull()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = null, Password = "Rohit123#", Email = "rohit@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(employee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }



        /// <summary>
        /// Employee Password can't be null
        /// </summary>
        [TestMethod]
        public async Task EmployeePasswordCanNotBeNull()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = "Mahendra", Password = null, Email = "mahendra@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(employee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Employee Email can't be null
        /// </summary>
        [TestMethod]
        public async Task EmployeeEmailCanNotBeNull()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = "Hardik", Password = "Hardik123#", Email = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(employee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// EmployeeName should contain at least two characters
        /// </summary>
        [TestMethod]
        public async Task EmployeeNameShouldContainAtLeastTwoCharacters()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = "J", Password = "Jasprit123#", Email = "jasprit@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(employee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }



        /// <summary>
        /// Password should be a valid password as per regular expression
        /// </summary>
        [TestMethod]
        public async Task EmployeePasswordRegExp()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = "Rishabh", Password = "Rishabh", Email = "rishabh@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(employee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Email should be a valid email as per regular expression
        /// </summary>
        [TestMethod]
        public async Task EmployeeEmailRegExp()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = "Rahul", Password = "Rahul123#", Email = "rahul" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(employee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
    }

    [TestClass]
    public class UpdateEmployeeBLTest
    {
        /// <summary>
        /// Update Employee to the Collection if it is valid.
        /// </summary>
        [TestMethod]
        public async Task UpdateValidEmployee()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee oldEmployee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(oldEmployee);
            Employee newEmployee = new Employee() { EmployeeName = "Virat Kohli", Password = "Virat123#", Email = "virat@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.UpdateEmployeeBL(oldEmployee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Employee Name can't be null
        /// </summary>
        [TestMethod]
        public async Task EmployeeNameCanNotBeNull()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee oldEmployee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(oldEmployee);
            Employee newEmployee = new Employee() { EmployeeName = null, Password = "Rohit123#", Email = "rohit@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.UpdateEmployeeBL(newEmployee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }



        /// <summary>
        /// Employee Password can't be null
        /// </summary>
        [TestMethod]
        public async Task EmployeePasswordCanNotBeNull()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee oldEmployee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(oldEmployee);
            Employee newEmployee = new Employee() { EmployeeName = "Mahendra", Password = null, Email = "mahendra@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.UpdateEmployeeBL(newEmployee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Employee Email can't be null
        /// </summary>
        [TestMethod]
        public async Task EmployeeEmailCanNotBeNull()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee oldEmployee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(oldEmployee);
            Employee newEmployee = new Employee() { EmployeeName = "Hardik", Password = "Hardik123#", Email = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(newEmployee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// EmployeeName should contain at least two characters
        /// </summary>
        [TestMethod]
        public async Task EmployeeNameShouldContainAtLeastTwoCharacters()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee oldEmployee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(oldEmployee);
            Employee newEmployee = new Employee() { EmployeeName = "J", Password = "Jasprit123#", Email = "jasprit@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(newEmployee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }



        /// <summary>
        /// Password should be a valid password as per regular expression
        /// </summary>
        [TestMethod]
        public async Task EmployeePasswordRegExp()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee oldEmployee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(oldEmployee);
            Employee newEmployee = new Employee() { EmployeeName = "Rishabh", Password = "Rishabh", Email = "rishabh@gmail.com" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(newEmployee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Email should be a valid email as per regular expression
        /// </summary>
        [TestMethod]
        public async Task EmployeeEmailRegExp()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee oldEmployee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(oldEmployee);
            Employee newEmployee = new Employee() { EmployeeName = "Rahul", Password = "Rahul123#", Email = "rahul" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await employeeBL.AddEmployeeBL(newEmployee);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }
    }

    [TestClass]
    public class DeleteEmployeeBLTest
    {
        [TestMethod]
        public async Task DeleteValidEmployee()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(employee);
            //Employee newEmployee = new Employee() { EmployeeName = "Virat Kohli", Password = "Virat123#", Email = "virat@gmail.com" };
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                isDeleted = await employeeBL.DeleteEmployeeBL(employee.EmployeeID);
            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isDeleted, errorMessage);
            }
        }
        [TestMethod]
        public async Task DeleteInValidEmployee()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();
            Employee employee = new Employee() { EmployeeName = "Virat", Password = "Virat123#", Email = "virat@gmail.com" };
            bool added = await employeeBL.AddEmployeeBL(employee);
            //Employee newEmployee = new Employee() { EmployeeName = "Virat Kohli", Password = "Virat123#", Email = "virat@gmail.com" };
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                isDeleted = await employeeBL.DeleteEmployeeBL(new Guid());
            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isDeleted, errorMessage);
            }
        }
    }

    [TestClass]
    public class EmployeeLoginBLTest
    {
        [TestMethod]
        public async Task ValidLogin()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();



            //Act
            Employee employee = await employeeBL.GetEmployeeByEmailAndPasswordBL("shobhit@gmail.com", "Shobhit123#");

            //Assert
            Assert.IsNotNull(employee);

        }

        [TestMethod]
        public async Task InValidEmployeeEmail()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();



            //Act
            Employee employee = await employeeBL.GetEmployeeByEmailAndPasswordBL("z@gmail.com", "Shobhit123#");

            //Assert
            Assert.IsNull(employee);

        }

        [TestMethod]
        public async Task InValidEmployeePassword()
        {
            //Arrange
            EmployeeBL employeeBL = new EmployeeBL();



            //Act
            Employee employee = await employeeBL.GetEmployeeByEmailAndPasswordBL("shobhit@gmail.com", "sho@15");

            //Assert
            Assert.IsNull(employee);

        }
    }
}

