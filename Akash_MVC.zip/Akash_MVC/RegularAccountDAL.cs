﻿//Created by Akash Kumar Singh

using Pecunia.Entities;
using Pecunia.Contracts.DALContracts;
using Pecunia.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Data.SqlClient;
using System.Data;
using System.Data.Entity.Core.Objects;

namespace Pecunia.DataAcessLayer
{

    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting account from Regular Accounts collection.
    /// </summary>
    public class RegularAccountDAL : RegularAccountDALBase, IDisposable
    {

        /// <summary>
        /// Adds new account to Regular Accounts collection.
        /// </summary>
        /// <param name="newAccount">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new account is added.</returns>
        public override bool CreateAccountDAL(RegularAccount newAccount)
        {
            try
            {
                using (TeamEEntities db = new TeamEEntities())
                {
                    ObjectResult<CreateRegularAccount_Result> CreateRegularAccount = db.CreateRegularAccount(newAccount.CustomerID, newAccount.AccountType, newAccount.Branch, newAccount.MinimumBalance, newAccount.InterestRate);
                    var result = CreateRegularAccount.FirstOrDefault();

                    int v = result.Column1;
                    newAccount.AccountNo = result.Column2;
                }
            }
            
            catch (Exception)
            {
                throw;
            }

            return true;
        }

        /// <summary>
        /// Gets all regular accounts from the collection.
        /// </summary>
        /// <returns>Returns list of all accounts.</returns>
        public override List<GetRegularAccountByAccountNo_Result> GetAllAccountsDAL()
        {
            try
            {
                using (TeamEEntities db = new TeamEEntities())
                {
                    List<GetRegularAccountByAccountNo_Result> AllRegularAccounts = db.GetAllRegularAccounts().ToList();
                    //List<RegularAccount> AllRegularAccounts = (from a in db.RegularAccounts select a).ToList();

                    return AllRegularAccounts;
                }
            }

           
            catch (Exception)
            {
                throw;
            }


        }



        /// <summary>
        /// Gets regular account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>Returns the matching RegularAccount.</returns>
        public override GetRegularAccountByAccountNo_Result GetAccountByAccountNoDAL(string searchAccountNo)
        {
            try
            {
                using (TeamEEntities db = new TeamEEntities())
                {
                    GetRegularAccountByAccountNo_Result existingAccount = db.GetRegularAccountByAccountNo(searchAccountNo).FirstOrDefault();
                    return existingAccount;

                }
            }

          
            catch (Exception)
            {
                throw;
            }



        }


        /// <summary>
        /// Gets list of regular accounts based on CustomerID
        /// </summary>
        /// <param name="searchCustomerID">Contains the Customer ID to search the accounts.</param>
        /// <returns>Returns the list of RegularAccounts  where the Customer ID matches.</returns>
        public override List<GetRegularAccountsByCustomerID_Result> GetAccountsByCustomerIDDAL(Guid searchCustomerID)
        {
            try
            {
                using (TeamEEntities db = new TeamEEntities())
                {

                    List<GetRegularAccountsByCustomerID_Result> RegularAccountsByCustomerID = db.GetRegularAccountsByCustomerID(searchCustomerID).ToList();

                    return RegularAccountsByCustomerID;
                }
            }

            catch (Exception)
            {
                throw;
            }



        }

        /// <summary>
        /// Gets list of regular accounts based on Account Type
        /// </summary>
        /// <param name="searchAccountType">Contains the type of regular account(Savings or Current) to search the accounts.</param>
        /// <returns>Returns the list of RegularAccount .</returns>
        public override List<GetRegularAccountsByAccountType_Result> GetAccountsByTypeDAL(string searchAccountType)
        {
            try
            {
                using (TeamEEntities db = new TeamEEntities())
                {

                    List<GetRegularAccountsByAccountType_Result> AccountsByType = db.GetRegularAccountsByAccountType(searchAccountType).ToList();

                    return AccountsByType;
                }
            }
           

            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// Gets list of regular accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the account in a particular branch.</param>
        /// <returns>Returns the list of Regular Account .</returns>
        public override List<GetRegularAccountsByBranch_Result> GetAccountsByBranchDAL(string searchBranch)
        {
            try
            {
                using (TeamEEntities db = new TeamEEntities())
                {

                    List<GetRegularAccountsByBranch_Result> AccountsByBranch = db.GetRegularAccountsByBranch(searchBranch).ToList();

                    return AccountsByBranch;
                }
            }

            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// Gets list of regular accounts based on range of dates
        /// </summary>
        /// <param name="startDate">Contains the starting date.</param>
        /// <param name="endDate">Contains the ending date.</param>
        /// <returns>Returns the list of RegularAccount .</returns>
        public override List<GetRegularAccountsByAccountOpeningDate_Result> GetAccountsByAccountOpeningDateDAL(DateTime startDate, DateTime endDate)
        {
            try
            {
                using (TeamEEntities db = new TeamEEntities())
                {

                    List<GetRegularAccountsByAccountOpeningDate_Result> AccountsByDate = db.GetRegularAccountsByAccountOpeningDate(startDate, endDate).ToList();

                    return AccountsByDate;
                }
            }
            
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// Gets Current Balance in the  regular account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public override double GetBalanceDAL(string accountNumber)
        {

            double balance = 0;


            return balance;
        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public override bool UpdateBalanceDAL(string accountNumber, double balance)
        {
            bool BalanceUpdated = false;


            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of a regular account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <param name="Branch">Contains the new branch</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public override bool UpdateBranchDAL(string accountNumber, string Branch)
        {
            try
            {
                bool AccountBranchUpdated = false;
                using (TeamEEntities db = new TeamEEntities())
                {
                    GetRegularAccountByAccountNo_Result account = GetAccountByAccountNoDAL(accountNumber);

                    if (account != null)
                    {
                        account.Branch = Branch;

                        int n = db.ChangeRegularAccountBranch(account.AccountNo, account.Branch);

                        AccountBranchUpdated = true;
                    }


                }

                return AccountBranchUpdated;
            }

            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// Updates the account type from savings to current or vice-versa
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <param name="accountType">Contains the new account type of the account.</param>
        /// <returns>Determines whether the account type is updated or not.</returns>
        public override bool UpdateAccountTypeDAL(string accountNumber, string accType)
        {
            try
            {
                bool AccountTypeUpdated = false;
                using (TeamEEntities db = new TeamEEntities())
                {
                    GetRegularAccountByAccountNo_Result account = GetAccountByAccountNoDAL(accountNumber);

                    if (account != null)
                    {
                        account.AccountType = accType;

                        int n = db.ChangeRegularAccountType(account.AccountNo, account.AccountType);

                        AccountTypeUpdated = true;
                    }


                }

                return AccountTypeUpdated;
            }

            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// Deletes an existing regular account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public override bool DeleteAccountDAL(string deleteAccountNo)
        {
            try
            {
                bool AccountDeleted = false;
                using (TeamEEntities db = new TeamEEntities())
                {
                    GetRegularAccountByAccountNo_Result account = GetAccountByAccountNoDAL(deleteAccountNo);

                    if (account != null)
                    {

                        int n = db.DeleteRegularAccount(deleteAccountNo);

                        AccountDeleted = true;
                    }


                }


                return AccountDeleted;
            }

            catch (Exception)
            {
                throw;
            }


        }


        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>

        public void Dispose()
        {
            //No unmanaged resources currently
        }
    }
}