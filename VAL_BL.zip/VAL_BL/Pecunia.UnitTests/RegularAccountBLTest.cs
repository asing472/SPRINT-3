﻿using System;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Pecunia.Entities;
using Pecunia.BusinessLayer;
using System.Collections.Generic;
using Pecunia.Contracts.DALContracts;

namespace Pecunia.UnitTests
{
    [TestClass]
    public class RegularAccountBLTest
    {
        [TestMethod]
        public async Task CreateValidRegularAccount()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "100001", AccountType = "Savings", Branch = "Delhi" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Customer No can't be null
        /// </summary>
        [TestMethod]
        public async Task CustomerNoCanNotBeNull()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = null, AccountType = "Savings", Branch = "Mumbai" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Type can't be null
        /// </summary>
        [TestMethod]
        public async Task AccountTypeCanNotBeNull()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "100002", AccountType = null, Branch = "Delhi" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch can't be null
        /// </summary>
        [TestMethod]
        public async Task BranchCanNotBeNull()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "100001", AccountType = "Current", Branch = null };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }


        /// <summary>
        /// Customer No should be a 6 digit no starting with 1
        /// </summary>
        [TestMethod]
        public async Task CustomerNoShouldBeValid()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "21267443", AccountType = "Savings", Branch = "Bengaluru" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch should be in ("Mumbai","Delhi","Chennai","Bengaluru")
        /// </summary>
        [TestMethod]
        public async Task BranchShouldBeValid()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regular = new RegularAccount() { CustomerNo = "100001", AccountType = "Current", Branch = "Kolkata" };
            bool isAdded = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regular);
            }
            catch (Exception ex)
            {
                isAdded = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isAdded, errorMessage);
            }
        }

        /// <summary>
        /// branch should be valid
        /// </summary>
        [TestMethod]
        public async Task UpdateValidBranch()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount = new RegularAccount() { CustomerNo = "100002", AccountType = "Savings", Branch = "Chennai" };
            bool isAdded = false;
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount);
                RegularAccount regularAccount1 = new RegularAccount() { AccountID = regularAccount.AccountID, CustomerNo = "100002", AccountType = "Savings", Branch = "Delhi" };
                isUpdated = await regularBL.UpdateBranchBL(regularAccount1);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Account Branch should be in ("Mumbai","Delhi","Chennai","Bengaluru") while updating the record
        /// </summary>
        [TestMethod]
        public async Task UpdateValidBranchError()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount = new RegularAccount() { CustomerNo = "100001", AccountType = "Current", Branch = "Bengaluru" };
            bool isAdded = false;
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount);
                RegularAccount regularAccount1 = new RegularAccount() { AccountID = regularAccount.AccountID, CustomerNo = "100001", AccountType = "Current", Branch = "Shimla" };
                isUpdated = await regularBL.UpdateBranchBL(regularAccount1);
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }

        /// <summary>
        /// Account no should be valid
        /// </summary>
       /* [TestMethod]
        public async Task UpdateAccountnoShouldBeValid()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            //RegularAccount regular = new RegularAccount() { AccountNo = "1000000002", Branch = "Bengaluru" };
            bool isUpdated = false;
            string errorMessage = null;

            //Act
            try
            {
                isUpdated = await regularBL.UpdateBranchBL();
            }
            catch (Exception ex)
            {
                isUpdated = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isUpdated, errorMessage);
            }
        }
        */

        /// <summary>
        /// Delete Valid Account
        /// </summary>
        [TestMethod]
        public async Task DeleteValidAccount()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount = new RegularAccount() { CustomerNo = "100001", AccountType = "Current", Branch = "Delhi" };
            bool isAdded = false;
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount);
                isDeleted = await regularBL.DeleteAccountBL(regularAccount.AccountNo);

            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isDeleted, errorMessage);
            }
        }


        /// <summary>
        /// Delete Valid Account
        /// </summary>
        [TestMethod]
        public async Task DeleteAccountNoShouldBeValid()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            //RegularAccount regularAccount = new RegularAccount() { CustomerNo = "100001", AccountType = "Current", Branch = "Delhi" };
            //bool isAdded = false;
            bool isDeleted = false;
            string errorMessage = null;

            //Act
            try
            {
                //isAdded = await regularBL.CreateAccountBL(regularAccount);
                isDeleted = await regularBL.DeleteAccountBL("10006523");

            }
            catch (Exception ex)
            {
                isDeleted = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsFalse(isDeleted, errorMessage);
            }
        }

        /// <summary>
        /// Search Account by Account No
        /// </summary>
        [TestMethod]
        public async Task SearchValidAccountNo()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            RegularAccount regularAccount = new RegularAccount() { CustomerNo = "100002", AccountType = "Savings", Branch = "Mumbai" };
            bool isAdded = false;
            bool isSearched = false;
            string errorMessage = null;

            //Act
            try
            {
                isAdded = await regularBL.CreateAccountBL(regularAccount);
                if (regularAccount.Equals(await regularBL.GetAccountByAccountNoBL(regularAccount.AccountNo)))
                {
                    isSearched = true;
                }
               
                
            }
            catch (Exception ex)
            {
                isSearched = false;
                errorMessage = ex.Message;
            }
            finally
            {
                //Assert
                Assert.IsTrue(isSearched, errorMessage);
            }
        }

        /// <summary>
        /// Search Account by Customer No
        /// </summary>
        /*
        [TestMethod]
        public async Task SearchValidCustomerNo()
        {
            //Arrange
            RegularAccountBL regularBL = new RegularAccountBL();
            List <RegularAccount> accounts = null;
            string errorMessage = null;
            List<RegularAccount> result = null;
            result.AddRange(RegularAccountDALBase.regularAccountList.FindAll(x => (x.CustomerNo.Equals("100002")))); ;
            
            
            //Act
            try
            {
                accounts = await regularBL.GetAccountsByCustomerNoBL("100002");
            }
            catch (Exception ex)
            {

                errorMessage = ex.Message;
            }

            finally
            {
                //Assert
                CollectionAssert.AreEqual(accounts, result);
            }
        }
        */

    }
}




