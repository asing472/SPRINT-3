﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    public interface iChequeBookBL : IDisposable
    {

        Task<bool> AddChequeBookBL(ChequeBook chequeBook);
        Task<List<ChequeBook>> GetAllChequeBooksBL();
        Task<bool> UpdateChequeBookStatusBL(ChequeBook chequeBook);
        Task<List<ChequeBook>> GetChequeBooksByAccountIdBL(Guid accountId);
        Task<List<ChequeBook>> GetChequeBooksByAccountIdAndStatusBL(Guid accountId, string status);
        Task<ChequeBook> GetChequeBookBySeriesStartBL(double seriesStart);
        Task<ChequeBook> GetChequeBookByChequeBookIdBL(Guid chequeBookId);


    }
}
