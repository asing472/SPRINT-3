﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;

namespace Pecunia.Contracts.BLContracts
{
    public interface ICarLoanBL : IDisposable
    {
        Task<bool> AddCarLoanBL(CarLoan newloan, string customenumber);
        Task<List<CarLoan>> GetAllCarLoanBL();
        Task<CarLoan> GetCarLoanByLoanIDBL(Guid loanID);

        Task<List<CarLoan>> GetCarLoanByLoanStatusBL(string LoanStatus);
        Task<bool> UpdateCarLoanBL(CarLoan updatedloan);
        Task<bool> DeleteCarLoanBL(Guid deleteLoanID);
    }

    public interface IHomeLoanBL : IDisposable
    {
        Task<bool> AddHomeLoanBL(HomeLoan newloan);
        Task<List<HomeLoan>> GetAllHomeLoanBL();
        Task<HomeLoan> GetHomeLoanByLoanIDBL(Guid loanID);

        Task<List<HomeLoan>> GetHomeLoanByLoanStatusBL(string LoanStatus);
        Task<bool> UpdateHomeLoanBL(HomeLoan updatedloan);
        Task<bool> DeleteHomeLoanBL(Guid deleteLoanID);

    }

    public interface IPersonalLoanBL : IDisposable
    {
        Task<bool> AddPersonalLoanBL(PersonalLoan newloan);
        Task<List<PersonalLoan>> GetAllPersonalLoanBL();
        Task<PersonalLoan> GetPersonalLoanByLoanIDBL(Guid loanID);

        Task<List<PersonalLoan>> GetPersonalLoanByLoanStatusBL(string LoanStatus);
        Task<bool> UpdatePersonalLoanBL(PersonalLoan updatedloan);
        Task<bool> DeleteLoanBL(Guid deleteLoanID);

    }

    public interface IEducationLoanBL : IDisposable
    {
        Task<bool> AddEducationLoanBL(EducationLoan newloan);
        Task<List<EducationLoan>> GetAllEducationLoanBL();
        Task<EducationLoan> GetEducationLoanByLoanIDBL(Guid loanID);

        Task<List<EducationLoan>> GetEducationLoanByLoanStatusBL(string LoanStatus);
        Task<bool> UpdateEducationLoanBL(EducationLoan updatedloan);
        Task<bool> DeleteEducationLoanBL(Guid deleteLoanID);

    }

}
