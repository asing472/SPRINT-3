﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    public interface iCreditCardBL : IDisposable
    {

        Task<bool> AddCreditCardBL(CreditCard CreditCard);
        Task<List<CreditCard>> GetAllCreditCardsBL();
        Task<bool> UpdateCreditCardStatusBL(CreditCard updateCreditCard);
        Task<List<CreditCard>> GetCreditCardsByCustomerIdBL(Guid customerId);
        Task<CreditCard> GetCreditCardByCreditCardNumberBL(string CreditCardNumber);


    }
}
