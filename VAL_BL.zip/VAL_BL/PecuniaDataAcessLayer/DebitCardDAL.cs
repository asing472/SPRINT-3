﻿using Pecunia.Entities;
using Pecunia.Contracts.DALContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.DataAcessLayer
{
    /// <summary>
    /// Contains  methods for inserting, updating and searching debitcards from DebitCards collection.
    /// </summary>

    public class DebitCardDAL : DebitCardDALBase, IDisposable
    {  /// <summary>
       /// Adds new debit card to DebitCards collection.
       /// </summary>
       /// <param name="debitCard">Contains the debit card details to be added.</param>
       /// <returns>Determinates whether the new debit card is added.</returns>
        public override bool AddDebitCardDAL(DebitCard debitCard)
        {
            bool debitCardIssued = false;
            try
            {
                debitCard.DebitCardId = Guid.NewGuid();
                debitCard.CardStatus = "Issued";
                debitCard.CardIssueDate = DateTime.Now;
                DateTime ExDate = debitCard.CardIssueDate.AddYears(5);
                double year = Convert.ToInt32(ExDate.ToString("yyyy"));
                double month = Convert.ToInt32(ExDate.ToString("MM"));
                debitCard.ExpiryMMYYYY = Convert.ToString(month) + "/" + Convert.ToString(year);
                debitCard.LastModifiedDate = DateTime.Now;
                debitCardsList.Add(debitCard);
                debitCardIssued = true;
            }
            catch (Exception)
            {
                throw;
            }
            return debitCardIssued;

        }
        /// <summary>
        /// Returns debit card list
        /// </summary>
        /// <returns> Returns the list of debit  cards</returns>
        public override List<DebitCard> GetDebitCardListDAL()
        {
            return debitCardsList;
        }
        /// <summary>
        /// Updates the status of debit card
        /// </summary>
        /// <param name="updateDebitCard">Contains the debitcard object for which we need to change status</param>
        
        /// <returns>Returns bool value if updated or not</returns>
        public override bool UpdateDebitCardStatusDAL(DebitCard updateDebitCard)
        {
            bool debitCardStatusChanged = false;
            try
            {
                DebitCard matchingDebitCard = GetDebitCardByDebitCardNumberDAL(updateDebitCard.CardNumber);
                if (matchingDebitCard != null)
                {

                    matchingDebitCard.CardStatus = updateDebitCard.CardStatus;
                    matchingDebitCard.LastModifiedDate = DateTime.Now;

                    debitCardStatusChanged = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return debitCardStatusChanged;
        }
        /// <summary>
        /// Gets debitCard based on debitCardID.
        /// </summary>
        /// <param name="debitId">Represents DebitCardID to search.</param>
        /// <returns>returns debit card details for respective debit card Id</returns>
        public override DebitCard GetDebitCardByDebitCardNumberDAL(string debitCardNumber)
        {
            DebitCard searchDebit = null;
            try
            {
                searchDebit = debitCardsList.Find(x => x.CardNumber == debitCardNumber);
            }
            catch (Exception)
            {
                throw;
            }
            return searchDebit;
        }
        /// <summary>
        /// Gets list of debitCards based on AccountID.
        /// </summary>
        /// <param name="accountId">Represents AccountID to search.</param>
        /// <returns>returns list of debit cards details for respective AccountId</returns>
        public override List<DebitCard> GetDebitCardsByAccountIdDAL(Guid accountId)
        {
            List<DebitCard> DebitCardsByAccountID = new List<DebitCard>();
            try
            {

                DebitCardsByAccountID.AddRange(debitCardsList.FindAll(x => x.AccountId == accountId));

            }
            catch (Exception)
            {
                throw;
            }
            return DebitCardsByAccountID;
        }



        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }

    }
}
